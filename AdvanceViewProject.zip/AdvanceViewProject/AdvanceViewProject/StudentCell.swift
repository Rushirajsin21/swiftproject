//
//  StudentCell.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit

class StudentCell: UITableViewCell {

    @IBOutlet weak var studStdLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var rollNoLbl: UILabel!
    @IBOutlet weak var studImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setStudentData(dict:NSMutableDictionary){
        //["studImg":"","studRollNo":"","studName":"","studStd":"","studDescription":""]
        if let name = dict["studName"] as? String{
            nameLbl.text? = "Name: " + name
        }
        if let studRollNo = dict["studRollNo"] as? String{
            rollNoLbl.text? = "Roll No: " + studRollNo
        }
        if let studStd = dict["studStd"] as? String{
            studStdLbl.text? = "Std :" + studStd
        }
        if let image = dict["studImg"] as? UIImage{
            studImage.image = image
        }
    }
}
