//
//  cell_View.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit

protocol ButtonDelegate{
    func onClickButtonClickMe(row: Int)
}

class cell_View: UITableViewCell {

    @IBOutlet weak var gameLbl: UILabel!
    @IBOutlet weak var btnClickMe: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var delegate: ButtonDelegate!
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func onClickClickMe(_ sender: Any) {
        if let _ = self.delegate{
            let row = btnClickMe.tag
            self.delegate.onClickButtonClickMe(row: row)
        
        }
    }
}
