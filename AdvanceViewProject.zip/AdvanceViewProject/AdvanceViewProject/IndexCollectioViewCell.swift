//
//  IndexCollectioViewCell.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 12/07/22.
//

import UIKit

class IndexCollectioViewCell: UICollectionViewCell {

   
    @IBOutlet weak var lblIndex: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    
    }

}
