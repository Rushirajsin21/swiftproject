//
//  toolbarview.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

protocol ToolbarViewDelegate {
    func onClickDonetoolBar()
    func onClickCancel()
}


class ToolbarView: UIView {

    var delegate: ToolbarViewDelegate!
    class func instanceFromNib() -> UIView {
        
        return UINib(nibName: "ToolbarView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        if let _ = self.delegate {
            self.delegate.onClickDonetoolBar()
        }
    }
    @IBAction func onClickCancel(_ sender: Any) {
        if let _ = self.delegate{
            self.delegate.onClickCancel()
        }
    }
    
}
