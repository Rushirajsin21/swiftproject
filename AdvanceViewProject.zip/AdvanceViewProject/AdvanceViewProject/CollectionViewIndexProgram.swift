//
//  CollectionViewIndexProgram.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 12/07/22.
//

import UIKit

class CollectionViewIndexProgram: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
  
    

    var index = [String] (repeating: "0", count: 25)
//    var index = ["0","1","2","3","4","5","6","7","8","9","10","11","12","13"]
    let ScreenSize = UIScreen.main.bounds
    @IBOutlet weak var collectioviewIndex: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.collectioviewIndex.delegate = self
        self.collectioviewIndex.dataSource = self
        self.collectioviewIndex.register(UINib(nibName: "IndexCollectioViewCell", bundle: nil), forCellWithReuseIdentifier: "IndexCollectioViewCell")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        

       return index.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let collectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "IndexCollectioViewCell", for: indexPath as IndexPath) as! IndexCollectioViewCell
        collectionCell.lblIndex.text = String(indexPath.row)
        
        return collectionCell
        
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height = 100
        let width = 100
        
        return CGSize(width: height, height: width)
    }

}
