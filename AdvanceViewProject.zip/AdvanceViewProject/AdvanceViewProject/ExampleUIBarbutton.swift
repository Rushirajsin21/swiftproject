//
//  ExampleUIBarbutton.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class ExampleUIBarbutton: UIViewController  {

    var a = "hello"
    @IBOutlet weak var barbtn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

        self.navigationItem.rightBarButtonItem = barbtn
      
    }

    @objc public func didTapMenuButton() {
        print("Hello World")
    }

    @IBAction func barbtn_click(_ sender: Any) {
       
        let story: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewcontroller1 = story.instantiateViewController(withIdentifier: "NewScr") as! NewScr
        viewcontroller1.b = "hello"
        
        self.navigationController?.pushViewController(viewcontroller1, animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
