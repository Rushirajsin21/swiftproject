//
//  ToolBarExample.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class ToolBarExample: UIViewController, ToolbarViewDelegate {
    
    
  
    

    
    @IBOutlet weak var txtname: UITextField!
  
    var toolView:ToolbarView!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        toolView = ToolbarView.instanceFromNib() as? ToolbarView
        self.toolView.delegate = self
      
        txtname.inputAccessoryView = toolView
      
   
        // Do any additional setup after loading the view.
    }
    
   
    
    
    func onClickDonetoolBar() {
        txtname.resignFirstResponder()
    }
    func onClickCancel() {
        print("cancel button pressed")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
