//
//  ViewController.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 05/07/22.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource {
    
    
   
    
    
    @IBOutlet weak var collection_view1: UICollectionView!
    

   
    @IBOutlet weak var tbl_View: UITableView!
    
    var city:[String]!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        city = ["Rajkot","Junagadh","Jamnagar","Ahemadavad","Surendranagar"]
        
        self.tbl_View.register(UINib(nibName: "tbl_view_cell", bundle: nil), forCellReuseIdentifier: "tbl_view_cell")
        self.collection_view1.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
        
        tbl_View.delegate = self
        tbl_View.dataSource = self
        collection_view1.delegate = self
        collection_view1.dataSource = self
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.city.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = tableView.dequeueReusableCell(withIdentifier: "tbl_view_cell", for: indexPath) as! tbl_view_cell
        cell1.lbtext.text = city[indexPath.row]
        return cell1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.city.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell2 = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath as IndexPath) as! CollectionViewCell
        cell2.lbtext1.text = city[indexPath.row]
        print(cell2.lbtext1.text!)
        return cell2
    }
}

