//
//  RootPageViewController.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 07/07/22.
//

import UIKit

class RootPageViewController: UIPageViewController, UIPageViewControllerDataSource {
  
    
   
    

    var vcList:[UIViewController] = {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let firstView = storyboard.instantiateViewController(withIdentifier: "FirstView") as! FirstView
        let secondView = storyboard.instantiateViewController(withIdentifier: "SecondView") as! SecondView
        
        return [firstView,secondView]
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.dataSource = self
        if let vc = vcList.first{
            self.setViewControllers([vc], direction: .forward, animated: true, completion: nil)
        }
        
       
    }
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let index = vcList.lastIndex(of: viewController) else { return nil}
        let previoudIndex = index - 1
        guard previoudIndex >= 0 else {return nil}
        guard previoudIndex < vcList.count else { return nil}
        return vcList[previoudIndex]
        
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        guard let index = vcList.lastIndex(of: viewController) else {return nil}
        let previousIndex = index + 1
        guard previousIndex >= 0 else {return nil}
        guard previousIndex < vcList.count else {return nil}
        return vcList[previousIndex]
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
