//
//  SecondNavigatedScreen.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class SecondNavigatedScreen: UIViewController {

    @IBOutlet weak var barbtn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.rightBarButtonItem = barbtn
    }
    
    
    
    @IBAction func barbtn_click(_ sender: Any) {
        let storyboard2: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let view2 = storyboard2.instantiateViewController(withIdentifier: "ThirdScreen")
        as! ThirdScreen
        view2.title = "Third"
        
        self.navigationController?.pushViewController(view2, animated: true)
        
    }
}
