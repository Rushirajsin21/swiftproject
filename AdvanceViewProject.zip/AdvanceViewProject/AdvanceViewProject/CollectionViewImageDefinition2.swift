//
//  CollectionViewImageDefinition2.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 12/07/22.
//

import UIKit

class CollectionViewImageDefinition2: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    let screenSize = UIScreen.main.bounds
    
    @IBOutlet weak var collectioviewimage: UICollectionView!
    
    var imagename = [UIImage(named: "user") , UIImage(named: "icSelected") , UIImage(named: "stud") , UIImage(named: "padlock") , UIImage(named: "calendar") ,UIImage(named: "email")]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.collectioviewimage.delegate = self
        self.collectioviewimage.dataSource = self
            
        self.collectioviewimage.register(UINib(nibName: "imageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "imageCollectionViewCell")
    
    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagename.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let collectioncell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCollectionViewCell", for: indexPath as IndexPath) as! imageCollectionViewCell
        collectioncell.image1.image = imagename[indexPath.row]
        
        return collectioncell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let w = Int(screenSize.size.width / 3)
        let height = 120
        let width = w
        return CGSize(width: width, height: height)
    }
}
