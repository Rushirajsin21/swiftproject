//
//  imageCollectionViewCell.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 12/07/22.
//

import UIKit

class imageCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var image1: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
