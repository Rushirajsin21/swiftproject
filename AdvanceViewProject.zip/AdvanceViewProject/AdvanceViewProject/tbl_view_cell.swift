//
//  tbl_view_cellTableViewCell.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 05/07/22.
//

import UIKit

class tbl_view_cell: UITableViewCell {

    @IBOutlet weak var lbtext: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
