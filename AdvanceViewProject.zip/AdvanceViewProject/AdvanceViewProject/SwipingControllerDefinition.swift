//
//  SwipingControllerDefinition.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 07/07/22.
//

import UIKit

class SwipingControllerDefinition: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var swipepagecontroll: UIPageControl!
    @IBOutlet weak var swipscrollview: UIScrollView!
    let ScreenSize = UIScreen.main.bounds
    var viewheight: CGFloat = 0.0
    var colors: [UIColor] = [UIColor.red, UIColor.blue , UIColor.green,UIColor.yellow , UIColor.gray]
    var frame: CGRect = CGRect(x: 0, y: 0, width: 0, height: 0)
    override func viewDidLoad() {
        super.viewDidLoad()

        configurePageControl()
        swipscrollview.delegate = self
      
//        swipscrollview.frame.size = ScreenSize.size
        print(swipscrollview.frame)
//        swipscrollview.frame = ScreenSize
        print(swipscrollview.frame)
        let screenheight = UIScreen.main.bounds.height
      print("Screen Height \(screenheight)")
       
       
        
        
        
        
        
        
      
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var topSafeArea: CGFloat
        var bottomSafeArea: CGFloat

        if #available(iOS 13.0, *) {
            topSafeArea = view.safeAreaInsets.top
            bottomSafeArea = view.safeAreaInsets.bottom
        } else {
            topSafeArea = topLayoutGuide.length
            bottomSafeArea = bottomLayoutGuide.length
        }
        print(topSafeArea)
        print(bottomSafeArea)
     
        viewheight = (topSafeArea + bottomSafeArea)
        for index in 0..<colors.count {
            frame.origin.x = swipscrollview.frame.width * CGFloat(index)
            frame.origin.y = 0
            frame.size = swipscrollview.frame.size
          
            print(frame)
            
            let subview = UIView(frame: frame)
            subview.backgroundColor = colors[index]
            let textlbl = UILabel(frame: CGRect(x: (swipscrollview.frame.maxX / 2) - (70/2) , y: (subview.frame.height / 2) - (50/2) , width: 70, height: 50))
            print( "subview frame: \(subview.frame.height / 2)")
            textlbl.backgroundColor = UIColor.white
           
           
            textlbl.tintColor = UIColor.black
            textlbl.textAlignment = .center
            textlbl.text = "Image \(index + 1)"
            subview.addSubview(textlbl)
            
            self.swipscrollview.addSubview(subview)
         
        }
        
        
        self.swipscrollview.contentSize = CGSize(width: ScreenSize.size.width * CGFloat(colors.count) , height: ScreenSize.size.height - topSafeArea - bottomSafeArea)
        print(ScreenSize.size.height - topSafeArea - bottomSafeArea)
        swipepagecontroll.addTarget(self, action: #selector(onChangePage), for: .valueChanged)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
       
        
        
        
        
        // safe area values are now available to use
    }
    @objc func onChangePage(){
        
        let x = CGFloat(swipepagecontroll.currentPage) * swipscrollview.frame.size.width
        swipscrollview.setContentOffset(CGPoint(x: x, y: 0), animated: true)
        
    }
    
    
    func configurePageControl(){
        self.swipepagecontroll.numberOfPages = colors.count
        self.swipepagecontroll.currentPage =  0
        self.swipepagecontroll.tintColor = UIColor.red
        self.swipepagecontroll.pageIndicatorTintColor = UIColor.black
        self.swipepagecontroll.currentPageIndicatorTintColor = UIColor.white
        
        
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = round(swipscrollview.contentOffset.x / swipscrollview.frame.size.width)
        swipepagecontroll.currentPage = Int(pageNumber)
        
    }

   

}
