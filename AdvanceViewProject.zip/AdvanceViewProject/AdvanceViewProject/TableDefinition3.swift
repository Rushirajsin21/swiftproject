//
//  TableDefinition3.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit

class TableDefinition3: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    

    var userName = ["Mitul","James","Martin","Mumbai"]
    var cityName = ["Rajkot","Ahemadabad","baroda","jack"]
    
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        self.tblView.delegate = self
        self.tblView.dataSource = self
        tblView.register(UINib(nibName: "tblViewCell", bundle: nil), forCellReuseIdentifier: "tblViewCell")
        
        
    }
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tblViewCell", for: indexPath) as! tblViewCell
        cell.userLbl.text = userName[indexPath.row]
        cell.cityLbl.text = cityName[indexPath.row]
        cell.separatorInset = UIEdgeInsets.zero
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = userName[indexPath.row]
        let city = cityName[indexPath.row]
        let alert = UIAlertController(title: user, message: city, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        print("User: \(user) , City: \(city)")
    }
}
