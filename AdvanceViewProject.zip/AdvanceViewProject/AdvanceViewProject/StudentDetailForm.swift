//
//  StudentDetailForm.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit
import PhotosUI


protocol DataToSend: AnyObject{
    func sendData(dictStudent:NSMutableDictionary)
}

class StudentDetailForm: UIViewController,UIImagePickerControllerDelegate,PHPickerViewControllerDelegate, UINavigationControllerDelegate {
   
 
    
 
    var delegate: DataToSend? = nil

    @IBOutlet  var btnCancel: UIButton!
    @IBOutlet  var btnSave: UIButton!
    @IBOutlet weak var txtDescription: UITextField!
    @IBOutlet weak var txtStd: UITextField!
    @IBOutlet weak var txtStudFullName: UITextField!
    @IBOutlet weak var txtStudRollNo: UITextField!
    @IBOutlet weak var imgForStud: UIImageView!
    @IBOutlet weak var btnForstudImg: UIButton!
    var displayDictionary:NSMutableDictionary!
    var btn:Bool!
    var dictData: Dictionary = ["studImg":"","studRollNo":"","studName":"","studStd":"","studDescription":""]
   var a = ""
    var imgpicker1 = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
    
        if displayDictionary == nil {
            displayDictionary = NSMutableDictionary()
        }
        else{
            if let name = displayDictionary["studName"] as? String{
                        print(name)
                txtStudFullName.text = name
                    }
                    if let studRollNo = displayDictionary["studRollNo"] as? String{
                        txtStudRollNo.text = studRollNo
                        print(studRollNo)
                    }
                    if let studStd = displayDictionary["studStd"] as? String{
                        txtStd.text = studStd
                        print(studStd)
                    }
                    if let image = displayDictionary["studImg"] as? UIImage{
                        imgForStud.image = image
                        print(image)
                    }
                    if let desc =  displayDictionary["studDescription"] as? String{
                        txtDescription.text = desc
                    }
        }
        
        if btn == nil {
            btn = false
        }
        
        txtStudRollNo.keyboardType = .numberPad
        txtStudFullName.keyboardType = .default
        txtStd.keyboardType = .numberPad
        txtDescription.keyboardType = .default
      
        btnSave.isHidden = btn
        btnCancel.isHidden = btn
        
      
    }
    
    func opengallery(){
        
        
        
        var config = PHPickerConfiguration()
        config.selectionLimit = 1
        
        config.filter = PHPickerFilter.images

        let pickerViewController = PHPickerViewController(configuration: config)
        pickerViewController.delegate = self
        self.present(pickerViewController, animated: true, completion: nil)
    }
    
    func checkField(txtstr: String ,textfieldName: String ) -> Bool {
       let txtstr1 = txtstr.trimmingCharacters(in: CharacterSet .whitespaces)
        if txtstr1.isEmpty{
            let alert = UIAlertController(title: "Invalid Input", message: "Please enter \(textfieldName)",preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if textfieldName == "Standard"{
            let b: Int = Int(txtStd.text!)!
                if b > 12 || b < 1 {
                    let alert2 = UIAlertController(title: "Invalid Input", message: "Please enter standard between 1 to 12", preferredStyle: .alert)
                    alert2.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alert2, animated: true, completion: nil)
                }
            }
        

            else if textfieldName == "Student Roll NO"{
                let a: Int = Int(txtStudRollNo.text!)!
                if a > 100 || a < 1{
                    print(txtstr1.hashValue > 100)
                    let alert1 = UIAlertController(title: "Invalid Input", message: "please enter roll no between 1 to 100", preferredStyle: .alert)
                    alert1.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alert1, animated: true, completion: nil)
                }
            }
            
        
        return true
  
    }
    @IBAction func onClickBtnForstudImg(_ sender: Any) {
    
        let alertimg = UIAlertController(title: "Media", message: "Select Image For Profile picture", preferredStyle: .actionSheet)
        alertimg.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.opengallery()
        }))
        
        alertimg.addAction(UIAlertAction(title: "Camera", style: .default, handler: { [self](cameraaction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                self.imgpicker1.delegate = self
                self.imgpicker1.sourceType = .camera
                self.imgpicker1.allowsEditing = false
                self.imgpicker1.modalPresentationStyle = .fullScreen
                self.present(self.imgpicker1, animated: true, completion: nil)
                
            }
            else{
                let alert2 = UIAlertController(title: "Alert", message: "device not have any Camera", preferredStyle: .alert)
                alert2.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alert2, animated: true, completion: nil)
            }
        }))
        alertimg.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alertimg, animated: true, completion: nil)
        
    }
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true, completion: nil)
        
        for result in results {
            result.itemProvider.loadObject(ofClass: UIImage.self, completionHandler: { (object, error) in
                if let image = object as? UIImage{
                    DispatchQueue.main.async {
                        
                        print("Selected Image: \(image)")
                        self.imgForStud.image = image
                    }
                }
                
            })
        }
        
    }
 
    override func viewDidAppear(_ animated: Bool) {
        
      
        
            
     
            }
    
 
//    func setDictDataToField(dataDict: NSMutableDictionary){
//        if let name = dataDict["studName"] as? String{
//            print(name)
//
//        }
//        if let studRollNo = dataDict["studRollNo"] as? String{
//
//            print(studRollNo)
//        }
//        if let studStd = dataDict["studStd"] as? String{
//
//            print(studStd)
//        }
//        if let image = dataDict["studImg"] as? UIImage{
//
//            print(image)
//        }
//    }
    
    
    @IBAction func onClickSave(_ sender: Any) {
//        var dictData: Dictionary = ["studImg":"","studRollNo":"","studName":"","studStd":"","studDescription":""]
    
        if imgForStud.image!.isEqualToImage(image: UIImage(named: "user")!) {
            let imgalert = UIAlertController(title: "Invalid input", message: "Please Select Image", preferredStyle: .alert)
            imgalert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(imgalert, animated: true, completion: nil)
        }
        else
        {
            var name:String = ""
            var rollNo:String = ""
            var std:String = ""
            var desc:String = ""
            if checkField(txtstr: txtStudRollNo.text!, textfieldName: "Student Roll NO"){
                rollNo = txtStudRollNo.text ?? ""
                
                    //dictData["studRollNo"] = txtStudRollNo.text
             
               
               
                
            }
            if checkField(txtstr: txtStudFullName.text!, textfieldName: "Student Name"){
                //dictData["studName"] = txtStudFullName.text
                name = txtStudFullName.text ?? ""
            }
            if checkField(txtstr: txtStd.text!, textfieldName: "Standard"){
                //dictData["studStd"] = txtStd.text
                std = txtStd.text ?? ""
            }
            if checkField(txtstr: txtDescription.text!, textfieldName: "Description"){
                //dictData["studDescription"] = txtDescription.text
                desc = txtDescription.text ?? ""
            }
            let dictStudent = createDictForStudent(rollNo: rollNo, Name: name, std: std, desc: desc, image: imgForStud.image!)
            delegate?.sendData(dictStudent: dictStudent)
            self.navigationController?.popViewController(animated: true )
    }
}
    func createDictForStudent(rollNo:String,Name:String,std:String,desc:String,image:UIImage) -> NSMutableDictionary{
        let dict = NSMutableDictionary()
        dict["studRollNo"] = rollNo
        dict["studName"] = Name
        dict["studStd"] = std
        dict["studDescription"] = desc
        dict["studImg"] = image
        return dict
    }
    @IBAction func onClickCancel(_ sender: Any) {
       
            self.navigationController?.popToRootViewController(animated: true)
        
    }
    


}

extension UIImage {

    func isEqualToImage(image: UIImage) -> Bool {
        let data1: NSData = self.pngData()! as NSData
        let data2: NSData = image.pngData()! as NSData
        return data1.isEqual(data2)
    }
}
