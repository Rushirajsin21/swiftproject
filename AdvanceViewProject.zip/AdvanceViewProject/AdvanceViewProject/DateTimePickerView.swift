//
//  DateTimePickerView.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 05/07/22.
//

import UIKit

class DateTimePickerView: UIViewController,UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource {
   
    
    

    var city:[String]!
    var filteredata:[String]!
    @IBOutlet weak var tblview: UITableView!
    @IBOutlet weak var uisearchbar: UISearchBar!
    @IBOutlet weak var timepicker: UIDatePicker!
    @IBOutlet weak var datepicker: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()

        city = ["Rajkot","surat","Jamnagar","Ahmadavad","Gandhinagar","Kutch"]
        
       filteredata = city
        
        self.uisearchbar.delegate = self
        
        self.tblview.register(UINib(nibName: "tbl_view_cell", bundle: nil), forCellReuseIdentifier: "tbl_view_cell")
        
     
        datepicker.addTarget(self, action: #selector(datechange), for: .valueChanged)
        timepicker.addTarget(self, action: #selector(timechange), for: .valueChanged)
        // Do any additional setup after loading the view.
    }
    
   @objc func datechange(){
       let date = Calendar.current.dateComponents([.month,.year,.day], from: datepicker.date)
       let day = date.day!
       let month = date.month!
       let year = date.year!
       print("\(day)/\(month)/\(year)")
       
   }
    @objc func timechange(){
     
       let dateFormatter = DateFormatter()
        
         dateFormatter.dateFormat = "hh:mm"
       let date1 = dateFormatter.string(from: timepicker.date)
//
       
       print("\(date1)")
       
   }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredata.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "tbl_view_cell", for: indexPath) as! tbl_view_cell
        cell2.lbtext?.text = filteredata[indexPath.row]
        
       return cell2
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        uisearchbar.text = filteredata[indexPath.row]
    }
   
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredata = searchText.isEmpty ? city : city.filter { (item: String) -> Bool in
                            // If dataItem matches the searchText, return true to include it
           
            return item.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        }
        
        if !searchText.isEmpty{
            tblview.isHidden = false
            self.tblview.dataSource = self
            tblview.reloadData()
            
        }
        else{
            tblview.isHidden = true
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
