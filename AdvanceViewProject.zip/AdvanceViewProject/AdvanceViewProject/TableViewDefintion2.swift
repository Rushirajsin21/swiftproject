//
//  TableViewDefintion2.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 08/07/22.
//

import UIKit

class TableViewDefintion2: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    var cityname = ["Rajkot", "Junagadh" , "Morbi", "Jamnagar", "Ahmedabad", "Surat", "baroda","","","","",""]

    @IBOutlet weak var tblView2: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblView2.delegate = self
        self.tblView2.dataSource = self
        self.tblView2.register(UINib(nibName: "tbl_view_cell", bundle: nil), forCellReuseIdentifier: "tbl_view_cell")
        // Do any additional setup after loading the view.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityname.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tbl_view_cell", for: indexPath) as! tbl_view_cell
        cell.lbtext.text = cityname[indexPath.row]
        return cell
        
    }

}
