//
//  StudentDetailDefinition4.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit

class StudentDetailDefinition4: UIViewController, DataToSend, UITableViewDelegate, UITableViewDataSource{
    
    
    
    @IBOutlet weak var tblStudView: UITableView!
    var studRollNo1:[String] = []
    var studName1:[String] = []
    var studStd1:[String] = []
    var studDescription1:[String] = []
    var studImage1:[UIImage] = []
    var arrStudentList:NSMutableArray!
    
    @IBOutlet weak var btnPlus: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        arrStudentList = NSMutableArray()
        
        self.tblStudView.register(UINib(nibName: "StudentCell", bundle: nil), forCellReuseIdentifier: "StudentCell")
        self.tblStudView.delegate = self
        self.tblStudView.dataSource = self
    
       
        
    }
  

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudentList.count//studRollNo1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath) as! StudentCell
        if let dict = arrStudentList.object(at: indexPath.row) as? NSMutableDictionary{
            cell.setStudentData(dict: dict)
        }
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let story2:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let view2 = story2.instantiateViewController(withIdentifier: "StudentDetailForm") as! StudentDetailForm
        //["studImg":"","studRollNo":"","studName":"","studStd":"","studDescription":""]
        
        print(arrStudentList!)
        
        
       
        
        
       
      
        
        let crudoperation = UIAlertController(title: "Option", message: "", preferredStyle: .actionSheet)
        crudoperation.addAction(UIAlertAction(title: "Edit", style: .default, handler: {_ in
            
            if let displayDict = self.arrStudentList.object(at: indexPath.row) as? NSMutableDictionary{
                view2.displayDictionary = displayDict
            }
            
            self.navigationController?.pushViewController(view2, animated: true)
        }))
        crudoperation.addAction(UIAlertAction(title: "View", style: .default, handler: {_ in
            
            if let displayDict = self.arrStudentList.object(at: indexPath.row) as? NSMutableDictionary{
                
                view2.displayDictionary = displayDict
            }
            view2.btn = true
            
            self.navigationController?.pushViewController(view2, animated: true)
        }))
        crudoperation.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: {_ in
            
            let deleteAlert = UIAlertController(title: "Warning", message: "Do you want to delete", preferredStyle: .alert)
            deleteAlert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: {_ in
                if let deleteDict = self.arrStudentList.object(at: indexPath.row) as? NSMutableDictionary{
                
                                self.arrStudentList.remove(deleteDict)
                                self.tblStudView.reloadData()
                            }
            }))
            deleteAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(deleteAlert, animated: true, completion: nil)

//
            
            
//            self.studImage1.remove(at: indexPath.row)
//            self.studRollNo1.remove(at: indexPath.row)
//            self.studName1.remove(at: indexPath.row)
//            self.studStd1.remove(at: indexPath.row)
//            self.studDescription1.remove(at: indexPath.row)
        }))
        crudoperation.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(crudoperation, animated: true, completion: nil)
        
        
        
    }

    @IBAction func onClickPlus(_ sender: Any) {
        print("demo")
        let story1:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let view1 = story1.instantiateViewController(withIdentifier: "StudentDetailForm") as! StudentDetailForm
        view1.delegate = self
        self.navigationController?.pushViewController(view1, animated: true)
        
    }
    func sendData(dictStudent:NSMutableDictionary) {
//        var dictData: Dictionary = ["studImg":"","studRollNo":"","studName":"","studStd":"","studDescription":""]
       // print(data["studName"]!)
        /*studImage1.append(img)
        studRollNo1.append(data["studRollNo"]!)
        studName1.append(data["studName"]!)
        studStd1.append(data["studStd"]!)
        studDescription1.append(data["studDescription"]!)*/
       
        arrStudentList.add(dictStudent)
        
        self.tblStudView.reloadData()
    }

}
