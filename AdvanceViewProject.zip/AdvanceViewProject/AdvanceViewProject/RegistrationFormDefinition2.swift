//
//  RegistrationFormDefinition2.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 07/07/22.
//

import UIKit

class RegistrationFormDefinition2: UIViewController {


    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtGender: UITextField!
    @IBOutlet weak var txtBirthDate: UITextField!
    
    
    
    
    @IBOutlet weak var Termslbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

     
      
        
        signupBtn.layer.cornerRadius = 5
        
       
        textLeftView(textfield: txtUsername, leftimage: "user")
      
        textLeftView(textfield: txtEmail, leftimage: "email")
        textLeftView(textfield: txtPassword, leftimage: "padlock")
        textLeftView(textfield: txtGender, leftimage: "couple")
        textLeftView(textfield: txtBirthDate, leftimage: "calendar")
        
        
      
        
        
        
//        let atribute1 = [NSAttributedString.Key.font: UIFont(name: "AvenirNext-Regular", size: 12)]
//
//        let nsstringand = NSMutableAttributedString(string: " and ", attributes: atribute1 as [NSAttributedString.Key :  Any])
//        Termslbl.attributedText = nsstring
//
//        let nsstring2 = NSMutableAttributedString(string: "Privacy Policy", attributes: atribute as [NSAttributedString.Key : Any])
//
//
//        let fullstring = NSMutableAttributedString()
//        fullstring.append(nsstring)
//        fullstring.append(nsstringand)
//        fullstring.append(nsstring2)
        
        Termslbl.attributedText = attributedText(firstString: "Terms and Condition", secondString: " and ", thirdstring: "Privacy Policy", firstfont: UIFont(name: "AvenirNext-Bold", size: 12)!, secondfont: UIFont(name: "AvenirNext-Regular", size: 12)!, thirdfont: UIFont(name: "AvenirNext-Bold", size: 12)!)
        
        Termslbl.isUserInteractionEnabled = true
        Termslbl.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onClickTermsandCondition)))
        
        
        // Do any additional setup after loading the view.
    }

    func attributedText(firstString:String, secondString:String, thirdstring:String, firstfont:UIFont, secondfont:UIFont, thirdfont:UIFont) -> NSMutableAttributedString {
        let FirstAttribute = [NSAttributedString.Key.font: firstfont]
        let FirstString = NSMutableAttributedString(string: firstString, attributes: FirstAttribute as [NSAttributedString.Key : Any])
        
        let SecondAttribute = [NSAttributedString.Key.font: secondfont]
        let SecondString = NSMutableAttributedString(string: secondString, attributes: SecondAttribute as [NSAttributedString.Key :  Any])
    
        let ThirdAttribute = [NSAttributedString.Key.font: thirdfont]
        let ThirdString = NSMutableAttributedString(string: thirdstring, attributes: ThirdAttribute as [NSAttributedString.Key : Any])
        
        let fullstring = NSMutableAttributedString()
        fullstring.append(FirstString)
        fullstring.append(SecondString)
        fullstring.append(ThirdString)
        
        
        return fullstring
    }
    
  

    @objc func onClickTermsandCondition(){
        print("Terms and condition")
    }
    func textLeftView(textfield: UITextField , leftimage:String ){
        textfield.leftViewMode = .always
        let img = UIImageView(frame: CGRect(x: 15, y: 0, width: 20, height: 20))
        img.image = UIImage(named: leftimage)
        let view1 = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 20))
         view1.backgroundColor = UIColor.white
        let view2 = UIView(frame: CGRect(x: img.frame.maxX + 10, y: (view1.frame.maxY / 2  ) - (10/2), width: 1, height: 10))
        view2.backgroundColor = UIColor.gray
        
         view1.addSubview(img)
        view1.addSubview(view2)
        
        textfield.leftView = view1
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
