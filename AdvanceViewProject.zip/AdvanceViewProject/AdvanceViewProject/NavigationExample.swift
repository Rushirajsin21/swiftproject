//
//  NavigationExample.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class NavigationExample: UIViewController {

    @IBOutlet weak var batbtn: UIBarButtonItem!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func batbtn_click(_ sender: Any) {
        let storyboard1: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let view1 = storyboard1.instantiateViewController(withIdentifier: "SecondNavigatedScreen") as! SecondNavigatedScreen
        view1.title = "Second"
        self.navigationController?.pushViewController(view1, animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
