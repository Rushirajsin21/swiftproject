//
//  CollectionViewCell.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 05/07/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lbtext1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
