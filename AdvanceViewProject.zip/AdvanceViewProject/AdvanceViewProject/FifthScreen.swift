//
//  FifthScreen.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class FifthScreen: UIViewController {

    @IBOutlet weak var thirdscreenbtn: UIBarButtonItem!
    @IBOutlet weak var homebtn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func thirdscreen_click(_ sender: Any) {
        
        let viewcontrollers = navigationController?.viewControllers
        var viewcontroller_third:UIViewController!
        
        if viewcontrollers!.count > 0 {
            for i in viewcontrollers! {
                if let view = i as? ThirdScreen {
                    viewcontroller_third = view
                    break
                }
            }
            
        }
        if viewcontroller_third != nil {
            self.navigationController?.popToViewController(viewcontroller_third, animated: true)
        }
      
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.rightBarButtonItem = homebtn
        self.navigationItem.hidesBackButton = false
        self.navigationItem.leftBarButtonItem = thirdscreenbtn
    }
    @IBAction func homebtn_click(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
