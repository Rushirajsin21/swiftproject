//
//  TabbarControllerExample.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class TabbarControllerExample: UIViewController {

    let tabbarcont = UITabBarController()
    override func viewDidLoad() {
        super.viewDidLoad()

        
       
        tabbarcont.tabBar.tintColor = UIColor.black
        createTabbar()
    }
    func createTabbar()
    {
        let firstvc = UIViewController()
        firstvc.title = "First1"
        firstvc.view.backgroundColor = UIColor.red
        firstvc.tabBarItem = UITabBarItem(title: "Home", image: UIImage(named: "HomeTab"), tag: 0)
        
        
        
        let secondvc = UIViewController()
        secondvc.title = "Second1"
        secondvc.view.backgroundColor = .gray
        secondvc.tabBarItem = UITabBarItem(title: "Location", image: UIImage(named: "Location"), tag: 1)
        
        let viewcontrollers = [firstvc,secondvc]
        tabbarcont.viewControllers = viewcontrollers.map{UINavigationController.init(rootViewController: $0)
            
        }
        self.view.addSubview(tabbarcont.view)
    }
    

   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
