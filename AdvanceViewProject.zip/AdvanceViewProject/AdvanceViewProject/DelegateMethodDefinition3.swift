//
//  DelegateMethodDefinition3.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 09/07/22.
//

import UIKit

class DelegateMethodDefinition3: UIViewController, UITableViewDelegate, UITableViewDataSource , ButtonDelegate {
   
   
   
    var games = ["Angry Birds","Chess","Russian Roulette","Spin The Bottle","Texas Hold'em Poker","Tic-Tac-Toe",]
   
    var index:Int!
    var btn:UIButton!
    
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.tblView.register(UINib(nibName: "cell_View", bundle: nil), forCellReuseIdentifier: "cell_View")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return games.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell_View", for: indexPath) as! cell_View
        cell.gameLbl.text = games[indexPath.row]
        cell.btnClickMe.setTitle("Click Me", for: .normal)
        cell.btnClickMe.tag = indexPath.row
        cell.delegate = self
        cell.separatorInset = UIEdgeInsets.zero
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        index = indexPath.row
    }
    func onClickButtonClickMe(row: Int)
    {

        let alert1 = UIAlertController(title: "Selected", message: "row is \(row + 1) ", preferredStyle: .alert)
        alert1.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert1, animated: true, completion: nil)
    }
    
}
