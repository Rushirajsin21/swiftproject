//
//  ThirdScreen.swift
//  AdvanceViewProject
//
//  Created by UBS_0R on 06/07/22.
//

import UIKit

class ThirdScreen: UIViewController {

    @IBOutlet weak var barbtn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.rightBarButtonItem = barbtn
        
    }
    
    @IBAction func barbtn_click(_ sender: Any) {
        let storyboard3: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let view3 = storyboard3.instantiateViewController(withIdentifier: "FourScreen") as! FourScreen
        view3.title = "Fourth"
        self.navigationController?.pushViewController(view3, animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
