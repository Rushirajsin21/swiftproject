//
//  LoginDefinition9.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class LoginDefinition9: UIViewController {

    let textusername = UITextField(frame: CGRect(x: 70, y: 100, width: 200, height: 40))
    let textpassword = UITextField(frame: CGRect(x: 70, y: 150, width: 200, height: 40))
    let btn_login = UIButton(frame: CGRect(x: 70, y: 200, width: 100, height: 40))
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        textusername.borderStyle = .bezel
        textusername.keyboardType = .emailAddress
        textusername.contentMode = .center
        textusername.clipsToBounds = true
       
        
        
        textpassword.borderStyle = .bezel
        textpassword.keyboardType = .default
        textpassword.isSecureTextEntry = true
        textpassword.contentMode = .center
        textpassword.clipsToBounds = true
        
        
        btn_login.setTitle("Login", for: .normal)
        btn_login.setTitleColor(UIColor.white, for: .normal)
        btn_login.backgroundColor = UIColor.black
        btn_login.addTarget(self, action: #selector(logincheck), for: .touchUpInside)
        
        
        
        self.view.addSubview(btn_login)
        self.view.addSubview(textusername)
        self.view.addSubview(textpassword)
    }
    @objc func logincheck(_ sender: UIButton){
        
        if textusername.text!.isValidEmail
        {
             if textpassword.text == "" {
                print("please Enter Password")
             }
            else{
                print("You are Login")
            }
        
            
        }
        else{
            print("please eneter valid email address")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension String {
    var isValidEmail: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
}
