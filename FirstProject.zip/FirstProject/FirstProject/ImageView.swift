//
//  ImageView.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class ImageView: UIViewController {
    let img2 = UIImageView(frame: CGRect(x: 00, y: 200, width: 100, height: 100))
    var documentsurls: URL{
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        let img = UIImageView(frame: CGRect(x: 60, y: 100, width: 100, height: 100))
//
//        img.layer.borderWidth = 3
//        img.layer.borderColor = UIColor.red.cgColor
//        img.layer.cornerRadius = 50
//        img.clipsToBounds = true
//        img.contentMode = .center
//        img.backgroundColor = UIColor.blue
    
        
        
       
        img2.layer.borderWidth = 3
        img2.layer.borderColor = UIColor.red.cgColor
        img2.layer.cornerRadius = 50
        img2.clipsToBounds = true
        img2.contentMode = .scaleAspectFit
        img2.backgroundColor = UIColor.blue
        
        
        let url = URL(string: "https://developerclouds.com/wp-content/uploads/2016/04/color-change-mouse.jpg")
        
        img2.image = loadurl(url: url!)
        
        
//        downloadImage(from: url!)
        
        
        
        
        
//    let imgnm = save(image: UIImage(named: "imgSelectedIcon") ?? UIImage())
//        img.image = load(filename: imgnm)
        
        
        
        
        self.view.addSubview(img2)
    
        
        
        
//        self.view.addSubview(img)
    }
    

    private func save (image: UIImage) ->String {
        let filname = "imgSelectedIcon.jpeg"
        let filurl = documentsurls.appendingPathComponent(filname)
        if let imageData =  image.jpegData(compressionQuality: 1.0){
            try? imageData.write(to: filurl,options: .atomic)
            
            return filname
        }
        print("error saving image")
        return ""
    }

    private func load(filename: String) -> UIImage?{
        
        let filurl = documentsurls.appendingPathComponent(filename)
        do{
            let imageData = try Data(contentsOf: filurl)
            return UIImage(data: imageData)
        }catch{
            print("Error loading image:\(error)")
        }
        return nil
        
    }
    
    private func loadurl(url: URL) -> UIImage?{
        
       
        do{
            let imageData = try Data(contentsOf: url)
//            let imageData = try NSData(contentsOf: url)
//            return UIImage(data: imageData! as Data)
            return UIImage(data: imageData)
        }catch{
            print("Error loading image:\(error)")
        }
        return nil
        
    }
    
   
    //    func getData(from url: URL, completion: @escaping (Data?,URLResponse?, Error?) -> () ){
    //        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    //    }
//   func downloadimg(from url: URL) {
//        print("Download Started")
//       getData(from: url){ data , response, error in
//           guard let data = data, error == nil else{ return }
//           print(response?.suggestedFilename ?? url.lastPathComponent)
//           print("Download Finished")
//
//           DispatchQueue.main.async() {
//               [weak self] in
//
//               self?.img2.image = UIImage(data: data)
//           }
//
//       }
//    }
    
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}


