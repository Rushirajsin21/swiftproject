//
//  USlider.swift
//  FirstProject
//
//  Created by UBS_0R on 27/06/22.
//

import UIKit

class USlider: UIViewController {

    @IBOutlet weak var slider2: UISlider!

    @IBOutlet weak var sl2: UILabel!
    let label1 = UILabel(frame: CGRect(x: 100, y: 90, width: 200, height: 200))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let slide1 = UISlider(frame: CGRect(x: 100, y: 200, width: 200, height: 50))
        slide1.minimumValue = 0
        slide1.maximumValue = 100
        slide1.value = 50
        slider2.value = 50
        label1.text = String(Int(slide1.value))
        sl2.text = String(Int(slider2.value))
        slider2.addTarget(self, action: #selector(slider2change), for: .valueChanged)
        slide1.addTarget(self, action: #selector(sliderChange), for: .valueChanged)
        
        self.view.addSubview(slide1)
        
        self.view.addSubview(label1)
        
    }
    @objc func sliderChange(_ sender:UISlider){
        label1.text = String(Int(sender.value))
    }
    @objc func slider2change(_ sender: UISlider){
        sl2.text = String(Int(slider2.value))
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
