//
//  UITextFieldDefinition.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class UITextFieldDefinition: UIViewController {

    let label1 = UILabel (frame: CGRect(x: 100, y: 150, width: 200, height: 50))
    let textfield1 = UITextField(frame: CGRect(x: 100, y: 100, width: 200, height: 50))
    override func viewDidLoad() {
        super.viewDidLoad()
        label1.text = ""
        // Do any additional setup after loading the view.
        
        
        textfield1.borderStyle = .roundedRect
        textfield1.clipsToBounds = true
        textfield1.contentMode = .center
        textfield1.addTarget(self, action: #selector(textchange), for: .editingChanged)
        
        
        self.view.addSubview(label1)
        self.view.addSubview(textfield1)
    }
    
    @objc func textchange(_ sender: UITextField){
        
        label1.text = textfield1.text
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
