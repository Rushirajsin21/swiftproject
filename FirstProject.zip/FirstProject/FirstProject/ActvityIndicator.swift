//
//  ActvityIndicator.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class ActvityIndicator: UIViewController {
    
    
    @IBOutlet weak var start2: UIButton!
    @IBOutlet weak var stop2: UIButton!
    @IBOutlet weak var activity2: UIActivityIndicatorView!
    let activiy1 = UIActivityIndicatorView(frame: CGRect(x: 60, y: 80, width: 200, height: 50))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
       
        activiy1.style = .medium
        activiy1.color = .red
        
       let start = UIButton(frame: CGRect(x: 100, y: 130, width: 50, height: 50))
        start.setTitle("start", for: .normal)
        start.backgroundColor = UIColor.blue
        start.addTarget(self, action: #selector(startspinner), for: .touchUpInside)
        start.layer.cornerRadius = 10
        start.layer.borderColor = UIColor.red.cgColor
        start.layer.borderWidth = 2
        
        let stop = UIButton(frame: CGRect(x: 170, y: 130, width: 50, height: 50))
         stop.setTitle("stop", for: .normal)
         stop.backgroundColor = UIColor.red
         stop.addTarget(self, action: #selector(stopspinner), for: .touchUpInside)
        
        stop.layer.cornerRadius = 10
        stop.layer.borderColor = UIColor.blue.cgColor
        stop.layer.borderWidth = 2
        
        
        activity2.style = .large
        activity2.color = .blue
        
        start2.setTitle("start", for: .normal)
        start2.backgroundColor = UIColor.blue
        start2.addTarget(self, action: #selector(startspinner2), for: .touchUpInside)
        start2.layer.cornerRadius = 10
        start2.layer.borderColor = UIColor.red.cgColor
        start2.layer.borderWidth = 2
        
        
         stop2.setTitle("stop", for: .normal)
         stop2.backgroundColor = UIColor.red
         stop2.addTarget(self, action: #selector(stopspinner2), for: .touchUpInside)
        
        stop2.layer.cornerRadius = 10
        stop2.layer.borderColor = UIColor.blue.cgColor
        stop2.layer.borderWidth = 2
        
         
         self.view.addSubview(stop)
        
        self.view.addSubview(start)
        self.view.addSubview(activiy1)
    }
    

    @objc func startspinner(){
        activiy1.startAnimating()
    }
    
    @objc func stopspinner(){
        activiy1.stopAnimating()
    }
    @objc func startspinner2(){
        activity2.startAnimating()
    }
    
    @objc func stopspinner2(){
        activity2.stopAnimating()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
