//
//  SwitchDefinition1.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class SwitchDefinition1: UIViewController {

    let lb1 = UILabel(frame: CGRect(x: 20, y: 50, width: 100, height: 50))
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let switch1 = UISwitch(frame: CGRect(x: 20, y: 100, width : 200, height: 50))
        
        lb1.text = "Switch is Off"
        
        lb1.textColor = UIColor.red
        switch1.setOn(false, animated: true)
        switch1.addTarget(self, action: #selector(switch1change), for: .valueChanged)
        // Do any additional setup after loading the view.
        let switch2 = UISwitch(frame: CGRect(x: 100, y: 200, width : 200, height: 50))
        
        switch2.setOn(true, animated: true)
        
        let switch3 = UISwitch(frame: CGRect(x: 160, y: 200, width : 200, height: 50))
        
        switch3.setOn(true, animated: true)
        switch3.thumbTintColor = UIColor.orange
//        switch3.onTintColor =
        switch3.onTintColor = UIColor(red: 29/255, green: 91/255, blue: 124/255, alpha: 1)
        
        let switch4 = UISwitch(frame: CGRect(x: 100, y: 250, width: 200, height: 50))
        switch4.setOn(true, animated: true)
        switch4.thumbTintColor = UIColor.black
        switch4.onTintColor = UIColor(red: 149/255, green: 164/255, blue: 177/255, alpha: 1)
        
        let switch5 = UISwitch(frame: CGRect(x: 160, y: 250, width: 200, height: 50))
        switch5.thumbTintColor = UIColor.red
        switch5.onTintColor = UIColor.cyan
        switch5.setOn(true, animated: true)

        self.view.addSubview(switch5)
        self.view.addSubview(switch4)
        self.view.addSubview(switch3)
        self.view.addSubview(switch2)
        self.view.addSubview(switch1)
        self.view.addSubview(lb1)
    }
    
    
    
    @objc func switch1change(_ sender: UISwitch){
        
        if (sender.isOn == true)
        {
            lb1.text = "Switch is On"
            lb1.textColor = UIColor.green
        }
        else{
            
                lb1.text = "Switch is Off"
                lb1.textColor = UIColor.red
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
