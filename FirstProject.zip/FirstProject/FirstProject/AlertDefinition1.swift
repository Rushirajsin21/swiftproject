//
//  AlertDefinition1.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class AlertDefinition1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let button1 = UIButton(frame: CGRect(x: 100, y: 50, width: 200, height: 40))
        button1.setTitle("Alert or Warnig", for: .normal)
        button1.setTitleColor(UIColor.white, for: .normal)
        button1.backgroundColor = UIColor.black
        button1.layer.cornerRadius = 5
        button1.layer.borderWidth = 2
        button1.layer.borderColor = UIColor.blue.cgColor
        button1.addTarget(self, action: #selector(showalert), for: .touchUpInside)
        
        let button2 = UIButton(frame: CGRect(x: 100, y: 100, width: 200, height: 40))
        button2.setTitle("Confirm Alert", for: .normal)
        button2.setTitleColor(UIColor.white, for: .normal)
        button2.backgroundColor = UIColor.blue
        button2.layer.cornerRadius = 5
        button2.layer.borderWidth = 2
        button2.layer.borderColor = UIColor.black.cgColor
        
        button2.addTarget(self, action: #selector(showconfirm), for: .touchUpInside)
        
        let button3 = UIButton(frame: CGRect(x: 100, y: 150, width: 200, height: 40 ))
        button3.setTitle("Multiple Option", for: .normal)
        
        button3.setTitleColor(UIColor.red,for: .normal)
        button3.backgroundColor = UIColor.green
        button3.layer.borderColor = UIColor.red.cgColor
        button3.layer.borderWidth = 2
        button3.layer.cornerRadius = 6
        button3.addTarget(self, action: #selector(showmultiple), for: .touchUpInside)
        
        
        self.view.addSubview(button3)
        self.view.addSubview(button2)
        self.view.addSubview(button1)
        // Do any additional setup after loading the view.
    }
    
    @objc func showmultiple(){
        let alert3 = UIAlertController(title: "Multiple Option", message: "This is multiple option message", preferredStyle: .alert)
        alert3.addAction(UIAlertAction(title: "Yes", style: .default, handler: {(alertact1) in print(alertact1.title!)}))
        
        alert3.addAction(UIAlertAction(title: "No", style: .default, handler: {(alertact2) in print(alertact2.title!)}))
        
        alert3.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {(alertact3) in
            print(alertact3.title!)
        }))
        
        
        self.present(alert3, animated: true, completion: nil)
    }
    
    @objc func showconfirm(_ sender2: UIButton){
        let alert2 = UIAlertController(title: "Confirm Alert", message: "This is Confirm Alert message", preferredStyle: .alert)
        alert2.addAction(UIAlertAction(title: "Yes", style: .default, handler: {(alertaction2) in
            print(String(describing: alertaction2.title!))}))
        alert2.addAction(UIAlertAction(title: "No", style: .default, handler: {(alertaction3) in print(alertaction3.title!)}))
        
        
        self.present(alert2, animated: true, completion: nil)
    }
    
    @objc func showalert(_ sender: UIButton){
        let alert1 = UIAlertController(title: "Alert or Warning", message: "Alert Message", preferredStyle: .alert)

        alert1.addAction(UIAlertAction(title: "Ok", style: .default, handler: {(alertaction) in print((alertaction.title!))}))
        self.present(alert1, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
