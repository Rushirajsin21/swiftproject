//
//  ImageViewDefinition.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class ImageViewDefinition: UIViewController {

    let img1 = UIImageView(frame: CGRect(x: 100, y: 100, width: 100, height: 100))
    let img2 = UIImageView(frame: CGRect(x: 100, y: 300, width: 100, height: 100))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        img1.image = UIImage(named: "imgSelectedIcon")
        
        let button1 = UIButton(frame: CGRect(x: 100, y: 200, width: 100, height: 50))
        button1.setTitle("Copy me", for: .normal)
        button1.setTitleColor(UIColor.blue, for: .normal)
        button1.addTarget(self, action:#selector(copyimage) , for: .touchUpInside)
    
        
        img2.image = UIImage(named: "redbutton")
        
        
        self.view.addSubview(button1)
        self.view.addSubview(img2)
        
        self.view.addSubview(img1)
        
    }
    
    @objc func copyimage(_ sender: UIButton){
        
        img2.image = img1.image
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
