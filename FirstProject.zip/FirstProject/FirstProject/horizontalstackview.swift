//
//  horizontalstackview.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class horizontalstackview: UIViewController {

    @IBOutlet weak var horizontal2: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let horizontal = UIStackView()
        horizontal.axis = NSLayoutConstraint.Axis.horizontal
        horizontal.distribution = UIStackView.Distribution.equalSpacing
        horizontal.alignment = UIStackView.Alignment.center
        horizontal.spacing = 16
        
        horizontal.layer.borderWidth = 0
        horizontal.layer.borderColor = UIColor.red.cgColor
        
        let textLabel = UILabel()
        textLabel.backgroundColor = UIColor.yellow
        textLabel.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel.text  = "Hi World"
        textLabel.textAlignment = .center
        
        let view2 = UIView()
                view2.backgroundColor = UIColor.red
        view2.widthAnchor.constraint(equalToConstant: 120).isActive = true
        view2.heightAnchor.constraint(equalToConstant: 120).isActive = true
                view2.clipsToBounds = true
                view2.layer.borderColor = UIColor.green.cgColor
                view2.layer.borderWidth = 2
                view2.layer.cornerRadius = 10
        
        let textLabel2 = UILabel()
        textLabel2.backgroundColor = UIColor.yellow
        textLabel2.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel2.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel2.text  = "Hi World2"
        textLabel2.textAlignment = .center
        
        
        let textLabel3 = UILabel()
        textLabel3.backgroundColor = UIColor.yellow
        textLabel3.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel3.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel3.text  = "Hi World3"
        textLabel3.textAlignment = .center
        
        let view3 = UIView()
                view3.backgroundColor = UIColor.blue
        view3.widthAnchor.constraint(equalToConstant: 120).isActive = true
        view3.heightAnchor.constraint(equalToConstant: 120).isActive = true
                view3.clipsToBounds = true
                view3.layer.borderColor = UIColor.green.cgColor
                view3.layer.borderWidth = 2
                view3.layer.cornerRadius = 10
//        let textLabel2 = UILabel()
//        textLabel2.backgroundColor = UIColor.yellow
//        textLabel2.widthAnchor.constraint(equalToConstant: self.view.frame.width).isActive = true
//        textLabel2.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
//        textLabel2.text  = "Hi World2"
//        textLabel2.textAlignment = .center
        
        
        horizontal.addArrangedSubview(textLabel)
        horizontal.addArrangedSubview(view2)
        horizontal.addArrangedSubview(textLabel2)
        
        horizontal2.addArrangedSubview(textLabel3)
        
        horizontal2.addArrangedSubview(view3)
//        horizontal2.addArrangedSubview(textLabel)
//        horizontal2.addArrangedSubview(view2)
//        horizontal2.addArrangedSubview(textLabel2)
        
        
        horizontal.translatesAutoresizingMaskIntoConstraints = false
        
//
//        let view1 = UIView(frame: CGRect(x: 0, y: 100, width: 100, height: 100))
//        view1.backgroundColor = UIColor.red
//        view1.clipsToBounds = true
//        view1.layer.borderColor = UIColor.green.cgColor
//        view1.layer.borderWidth = 2
//        view1.layer.cornerRadius = 10
//
//        let view2 = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//        view2.backgroundColor = UIColor.red
//        view2.clipsToBounds = true
//        view2.layer.borderColor = UIColor.green.cgColor
//        view2.layer.borderWidth = 2
//        view2.layer.cornerRadius = 10
//
//        horizontal.addArrangedSubview(view1)
//        horizontal.addArrangedSubview(view2)
//
//        horizontal.translatesAutoresizingMaskIntoConstraints = false
//        self.view.addSubview(view1)
//        self.view.addSubview(view2)
        self.view.addSubview(horizontal)
        
        horizontal.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        horizontal.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
