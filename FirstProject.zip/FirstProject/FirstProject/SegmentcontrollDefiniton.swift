//
//  SegmentcontrollDefiniton.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class SegmentcontrollDefiniton: UIViewController {

    let view1 = UIView(frame: CGRect(x: 70, y: 180, width: 200, height: 50))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view1.backgroundColor = UIColor.orange
        let item = ["Green","Orange","Cyan"]
        let segmen1 = UISegmentedControl(items: item)
        segmen1.frame = CGRect(x: 70, y: 100, width: 200, height: 50)
        segmen1.selectedSegmentIndex = 1
        segmen1.tintColor = .cyan
        segmen1.layer.borderWidth = 1
        segmen1.layer.borderColor = UIColor.systemTeal.cgColor
        segmen1.selectedSegmentTintColor = UIColor.systemTeal
        segmen1.addTarget(self, action: #selector(segmentchange1), for: .valueChanged)
        
        
        self.view.addSubview(view1)
        self.view.addSubview(segmen1)
    }
    @objc func segmentchange1(_ sender: UISegmentedControl){
        switch (sender.selectedSegmentIndex){
        case 0:
            view1.backgroundColor = UIColor.green
            break

        case 1:
            view1.backgroundColor = UIColor.orange
            break
            
        case 2:
            view1.backgroundColor = UIColor.cyan
            break
            
        default :
            view1.backgroundColor = UIColor.orange
            break
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
