//
//  listViewRootNavigation.swift
//  FirstProject
//
//  Created by UBS_0R on 01/07/22.
//

import UIKit

class listViewRootNavigation: UIViewController {

    var txtNumber: UITextField!
    var btnSend: UIButton!
    var list2 = ["1"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtNumber = UITextField(frame: CGRect(x: 50, y: 100, width: 200, height: 40))
        txtNumber.borderStyle = .roundedRect
        txtNumber.textColor = .blue
        txtNumber.contentMode = .scaleToFill
        
        btnSend = UIButton(frame: CGRect(x: 50, y: 150, width: 200, height: 40))
        btnSend.setTitle("Send", for: .normal)
        btnSend.setTitleColor(UIColor.blue, for: .normal)
        btnSend.backgroundColor = .green
        btnSend.contentMode = .scaleToFill
        btnSend.layer.borderColor = UIColor.red.cgColor
        btnSend.layer.borderWidth = 2
        btnSend.layer.cornerRadius = 5
        btnSend.addTarget(self, action: #selector(btnsendtonextscreen), for: .touchUpInside)
        
        
        
        self.view.addSubview(btnSend)
        self.view.addSubview(txtNumber)
    }
    
    @objc func btnsendtonextscreen(_ sender: UIButton){
        let storyboard1: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewcontroller1 = storyboard1.instantiateViewController(withIdentifier: "LisViewNavigatedController") as! LisViewNavigatedController
        list2.append(txtNumber.text!)
        viewcontroller1.list1 = list2
        self.navigationController?.pushViewController(viewcontroller1, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
