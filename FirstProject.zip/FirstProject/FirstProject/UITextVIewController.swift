//
//  UITextViewController.swift
//  FirstProject
//
//  Created by UBS_0R on 27/06/22.
//

import UIKit

class UITextViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let text1 = UITextView(frame: CGRect(x: 100, y: 200, width: 100, height: 50))
        text1.layer.borderWidth = 1
        text1.layer.borderColor = UIColor.red.cgColor
        text1.layer.cornerRadius = 5
        text1.textColor = UIColor.blue
        text1.backgroundColor = UIColor.green
        text1.textAlignment = .center
        text1.keyboardType = UIKeyboardType.default
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        toolbar.barStyle = .default
        toolbar.items = [
        UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelNumberPad)),
        UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
        UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneWithNumberPad))]
        toolbar.sizeToFit()
        text1.inputAccessoryView = toolbar
        
        self.view.addSubview(text1)
        // Do any additional setup after loading the view.
    }
    
    @objc func cancelNumberPad(){
        
    }
    @objc func doneWithNumberPad(){
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
