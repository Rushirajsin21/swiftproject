//
//  VerticalStackVeiw.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class VerticalStackVeiw: UIViewController {

    @IBOutlet weak var vertical2: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let vertical1 = UIStackView()
        vertical1.axis = NSLayoutConstraint.Axis.vertical
        vertical1.spacing = 10
        vertical1.distribution = .equalSpacing
        vertical1.alignment = .center
        vertical1.layer.borderWidth = 0
        vertical1.layer.borderColor = UIColor.red.cgColor
        
        let textLabel = UILabel()
        textLabel.backgroundColor = UIColor.green
        textLabel.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel.text  = "Hi World"
        textLabel.textAlignment = .center
        
        let view2 = UIView()
                view2.backgroundColor = UIColor.blue
        view2.widthAnchor.constraint(equalToConstant: 120).isActive = true
        view2.heightAnchor.constraint(equalToConstant: 120).isActive = true
                view2.clipsToBounds = true
                view2.layer.borderColor = UIColor.green.cgColor
                view2.layer.borderWidth = 2
                view2.layer.cornerRadius = 10
        
        let textLabel2 = UILabel()
        textLabel2.backgroundColor = UIColor.green
        textLabel2.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel2.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel2.text  = "Hi World 2"
        textLabel2.textAlignment = .center
        
        let textLabel3 = UILabel()
        textLabel3.backgroundColor = UIColor.green
        textLabel3.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel3.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel3.text  = "Hi World"
        textLabel3.textAlignment = .center
        
        let view3 = UIView()
                view3.backgroundColor = UIColor.blue
        view3.widthAnchor.constraint(equalToConstant: 120).isActive = true
        view3.heightAnchor.constraint(equalToConstant: 120).isActive = true
                view3.clipsToBounds = true
                view3.layer.borderColor = UIColor.green.cgColor
                view3.layer.borderWidth = 2
                view3.layer.cornerRadius = 10
        let textLabel4 = UILabel()
        textLabel4.backgroundColor = UIColor.green
        textLabel4.widthAnchor.constraint(equalToConstant: 120).isActive = true
        textLabel4.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
        textLabel4.text  = "Hi World"
        textLabel4.textAlignment = .center
        
        
        vertical1.addArrangedSubview(textLabel)
        vertical1.addArrangedSubview(view2)
       
        vertical1.addArrangedSubview(textLabel2)
        
        vertical1.translatesAutoresizingMaskIntoConstraints = false
        
        vertical2.addArrangedSubview(textLabel3)
        vertical2.addArrangedSubview(view3)
        vertical2.addArrangedSubview(textLabel4)
        
        self.view.addSubview(vertical1)
        vertical1.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = false
        vertical1.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
