//
//  UIViewButtonDefinition7.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class UIViewButtonDefinition7: UIViewController {

   
    @IBOutlet weak var view1: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
  
   
    
  
    
    @IBAction func s200_click(_ sender: Any) {
        view1.frame = CGRect(x: 10, y: 10, width: 200, height: 200)
    }
   
    @IBAction func s250_click(_ sender: Any) {
        view1.frame = CGRect(x: 10, y: 10, width: 250, height: 250)
    }
    @IBAction func s300_click(_ sender: Any) {
        view1.frame = CGRect(x: 10, y: 10, width: 300, height: 300)
    }
    @IBAction func r0_click(_ sender: Any) {
        view1.layer.cornerRadius = 0
    }
    @IBAction func r20_click(_ sender: Any) {
        view1.layer.cornerRadius = 20
    }
    @IBAction func r100_click(_ sender: Any) {
        view1.layer.cornerRadius = 100
    }
    @IBAction func border_0(_ sender: Any) {
        view1.layer.borderWidth = 0
        view1.layer.borderColor = UIColor.green.cgColor
    }
    @IBAction func border1_click(_ sender: Any) {
        view1.layer.borderWidth = 1
        view1.layer.borderColor = UIColor.green.cgColor
    }
    @IBAction func border10_click(_ sender: Any) {
        view1.layer.borderWidth = 10
        view1.layer.borderColor = UIColor.green.cgColor
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
