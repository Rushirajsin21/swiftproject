//
//  ImageTakingViewController.swift
//  FirstProject
//
//  Created by UBS_0R on 01/07/22.
//

import UIKit
import PhotosUI
import Cosmos



class ImageTakingViewController: UIViewController, UIImagePickerControllerDelegate , PHPickerViewControllerDelegate, UINavigationControllerDelegate,
    UIPickerViewDelegate,
    UIPickerViewDataSource
    
{
    
    
   
    
   
    @IBOutlet weak var btn_clear: UIButton!
    
    @IBOutlet weak var btn_register: UIButton!
    
    @IBOutlet weak var starview: CosmosView!
    
    @IBOutlet weak var daytimepicker: UIDatePicker!
    @IBOutlet weak var writinghobbies_checkbox: UIButton!
    @IBOutlet weak var Dancinghobbies_checkbox: UIButton!
    
    @IBOutlet weak var Paintinghobbies_checkbox: UIButton!
    @IBOutlet weak var crickethobbies_checkbox: UIButton!
    @IBOutlet weak var readinghobies_checkbox: UIButton!
    
    @IBOutlet weak var cityButton: UIButton!
    @IBOutlet weak var cityPickerView: UIPickerView!
    @IBOutlet weak var birthDatePicker: UIDatePicker!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var btngenderFemale: UIButton!
    
    @IBOutlet weak var btngenderMale: UIButton!
    @IBOutlet weak var txtviewaddress: UITextView!
    @IBOutlet weak var lblusername: UILabel!
    @IBOutlet weak var txtusername: UITextField!
    
   var citylist = ["Rajkot","Ahemadabad","Gandhinagar","Surendranagar","Jamnagar"]
    @IBOutlet weak var imageview1: UIImageView!
    var imgpicker1 = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        
        cityButton.layer.cornerRadius = 9
        cityPickerView.isHidden = true
//        txtEmail.addTarget(self, action: #selector(logincheck), for: .editingDidEnd)
        
        txtviewaddress.layer.borderWidth = 1
        txtviewaddress.layer.borderColor = UIColor.lightGray.cgColor
        txtviewaddress.layer.cornerRadius = 3
        print(starview.rating)
        
        
    
      
        
    

   
        
        
        
        
        
       
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func btnRegister_click(_ sender: Any) {
        let usertex = txtusername.text!.trimmingCharacters(in: CharacterSet .whitespaces)
        let viewaddresstex = txtviewaddress.text.trimmingCharacters(in: CharacterSet .whitespaces)
        
        let minimumbirthdate = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
        let maximumbirthdate = Calendar.current.date(byAdding: .year, value: -100, to: Date())!
        
        
        
        
        if usertex.isEmpty {
            let aler1 = UIAlertController(title: "Invalid Input", message: "Please Enter Username", preferredStyle: .alert)
            aler1.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(aler1, animated: true, completion: nil)
        }
        
        else if viewaddresstex.isEmpty{
            let alert2 = UIAlertController(title: "Invalid Input", message: "Please Enter Address", preferredStyle: .alert)
            alert2.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert2, animated: true, completion: nil)
        }
        else if txtEmail.text!.isValidEmail1 == false {
            let alert3 = UIAlertController(title: "Invalid Input", message: "Please Enter Email address", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert3, animated: true, completion: nil)
        }
        else if birthDatePicker.date > minimumbirthdate || birthDatePicker.date <= maximumbirthdate  {
            let alert3 = UIAlertController(title: "Invalid Input", message: "Invalid Birth Date ", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert3, animated: true, completion: nil)
        }

        
        else if cityButton.titleLabel?.text == "Select" {
            let alert3 = UIAlertController(title: "Invalid Input", message: "please select City name ", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert3, animated: true, completion: nil)
        }
        else if readinghobies_checkbox.isSelected == false && crickethobbies_checkbox.isSelected == false && Paintinghobbies_checkbox.isSelected == false && Dancinghobbies_checkbox.isSelected == false && writinghobbies_checkbox.isSelected == false
        {
            let alert3 = UIAlertController(title: "Invalid Input", message: "please select atleast one hobbies ", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert3, animated: true, completion: nil)
            
        }
        else {
            let alert3 = UIAlertController(title: "Successfull", message: "You are Registered Successfully", preferredStyle: .alert)
            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert3, animated: true, completion: nil)
            print("Username : \(txtusername.text!)")
            print("Address  : \(txtviewaddress.text!)")
            if btngenderMale.isSelected{
                print("Gender  : \(btngenderMale.titleLabel!.text!)")
            }
            else if btngenderFemale.isSelected {
                print("Gender  : \(btngenderFemale.titleLabel!.text!)")
            }
            print("Email  : \(txtEmail.text!)")
            print("Birth Date  : \(birthDatePicker.date)")
            print("City  : \(cityButton.titleLabel!.text!)")
            print("Hobbies  :",terminator:" ")
            if readinghobies_checkbox.isSelected {
                print("\(readinghobies_checkbox.titleLabel!.text!)", terminator: " ,")
            }
            if crickethobbies_checkbox.isSelected {
                print(crickethobbies_checkbox.titleLabel!.text!,terminator: " ,")
            }
            if Paintinghobbies_checkbox.isSelected {
                print(Paintinghobbies_checkbox.titleLabel!.text!,terminator: " ,")
            }
            if Dancinghobbies_checkbox.isSelected {
                print(Dancinghobbies_checkbox.titleLabel!.text!,terminator: " ,")
            }
            if writinghobbies_checkbox.isSelected {
                print(writinghobbies_checkbox.titleLabel!.text!)
            }
            print("Day Time  : \(daytimepicker.date.formatted(.dateTime))")
            print("Rating  : \(starview.rating)")
        }
        
        
    }
    
    
    @IBAction func btnClear_click(_ sender: Any) {
        
    }
    
    @IBAction func writing_checked(_ sender: Any) {
        if writinghobbies_checkbox.isSelected{
            writinghobbies_checkbox.isSelected = false
        }
        else{
            writinghobbies_checkbox.isSelected = true
        }
        
    }
    @IBAction func dancing_checked(_ sender: Any) {
        if Dancinghobbies_checkbox.isSelected{
            Dancinghobbies_checkbox.isSelected = false
        }
        else{
            Dancinghobbies_checkbox.isSelected = true
        }
        
    }
    @IBAction func painting_checked(_ sender: Any) {
        if Paintinghobbies_checkbox.isSelected{
            Paintinghobbies_checkbox.isSelected = false
        }
        else{
            Paintinghobbies_checkbox.isSelected = true
        }
        
    }
    
    @IBAction func reading_checked(_ sender: Any) {
        
        if readinghobies_checkbox.isSelected{
            readinghobies_checkbox.isSelected = false
        }
        else{
            readinghobies_checkbox.isSelected = true
        }
        
    }
    
    
    
    @IBAction func cricket_checked(_ sender: Any) {
        if crickethobbies_checkbox.isSelected{
            crickethobbies_checkbox.isSelected = false
        }
        else{
            crickethobbies_checkbox.isSelected = true
        }
        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return citylist.count

    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return citylist[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {

        cityPickerView.selectRow(row, inComponent: component, animated: true)

        cityButton.setTitle(citylist[cityPickerView.selectedRow(inComponent: component)], for: .normal)
        cityPickerView.isHidden = true
        cityButton.isHidden = false



    }


    @IBAction func citypicker_click(_ sender: Any) {
        self.cityPickerView.delegate = self
        self.cityPickerView.dataSource = self
        cityPickerView.isHidden = false
        cityButton.isHidden = true

    }
    
    @IBAction func genderMale_click(_ sender: Any) {
        if btngenderMale.isSelected {
            btngenderFemale.isSelected = false
            
        }
        else{
            btngenderMale.isSelected = true
            btngenderFemale.isSelected = false
        }
        
    }
    
    
    
    @IBAction func genderFemale_click(_ sender: Any) {
        if btngenderFemale.isSelected {
            btngenderMale.isSelected = false
        }
        else{
            btngenderFemale.isSelected = true
            btngenderMale.isSelected = false
        }
    }
    
    
    
    
    
    
    
    
    
    func opengallery(){
        
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
//            self.imgpicker1.delegate = self
//            self.imgpicker1.sourceType = .photoLibrary
//            self.imgpicker1.allowsEditing = false
//            self.imgpicker1.modalPresentationStyle = .fullScreen
//            self.present(self.imgpicker1, animated: true, completion: nil)
//
//
//
//        }
//        else{
//            let alert3 = UIAlertController(title: "Alert", message: "device not have any Gallery", preferredStyle: .alert)
//            alert3.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
//            self.present(alert3, animated: true, completion: nil)
//        }
        
        
        var config = PHPickerConfiguration()
        config.selectionLimit = 3
        config.filter = PHPickerFilter.images

        let pickerViewController = PHPickerViewController(configuration: config)
        pickerViewController.delegate = self
        self.present(pickerViewController, animated: true, completion: nil)
    }
    
    @IBAction func image_picker(_ sender: Any) {
        let alert1 = UIAlertController(title: "Media", message: "Select Image or Take Photo", preferredStyle: .actionSheet)


        alert1.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.opengallery()
        }))
        alert1.addAction(UIAlertAction(title: "Camera", style: .default, handler: { [self](cameraaction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                self.imgpicker1.delegate = self
                self.imgpicker1.sourceType = .camera
                self.imgpicker1.allowsEditing = false
                self.imgpicker1.modalPresentationStyle = .fullScreen
                self.present(self.imgpicker1, animated: true, completion: nil)
                
            }
            else{
                let alert2 = UIAlertController(title: "Alert", message: "device not have any Camera", preferredStyle: .alert)
                alert2.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alert2, animated: true, completion: nil)
            }
        }))

        self.present(alert1, animated: true, completion: nil)
        
    }
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
       picker.dismiss(animated: true, completion: nil)
       
       for result in results {
          result.itemProvider.loadObject(ofClass: UIImage.self, completionHandler: { (object, error) in
             if let image = object as? UIImage {
                DispatchQueue.main.async {
                   // Use UIImage
                   print("Selected image: \(image)")
                    self.imageview1.image = image
                    
                    
                }
             }
          })
       }
    }
    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!){
         self.dismiss(animated: true, completion: nil)
        
        imageview1.image = image
        
        imageview1.layer.borderWidth = 10
        self.view.addSubview(imageview1)
    }
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    @objc func logincheck(_ sender: UIButton){
//
//        if txtEmail.text!.isValidEmail1
//        {
//             if txtEmail.text == "" {
//                print("please Enter Email")
//             }
//            else{
//                print("You are Login")
//            }
//
//
//        }
//        else{
//            print("please eneter valid email address")
//        }
//    }
    
    

}
extension String {
    var isValidEmail1: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
}
