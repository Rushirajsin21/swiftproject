//
//  ProgressbarDefinition.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class ProgressbarDefinition: UIViewController {

    var timer1: Timer?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let progress1 = UIProgressView(frame: CGRect(x: 85, y: 200, width: 150, height: 50))
        progress1.progressViewStyle = .bar
      
        progress1.setProgress(0.0, animated: true)
        progress1.trackTintColor = UIColor.lightGray
        progress1.tintColor = UIColor.blue
        
        let txt1 = UILabel(frame: CGRect(x: 30, y: 176, width: 200, height: 50))
        txt1.text = "0"
        
        
        
        let txt2 = UILabel(frame: CGRect(x: 250, y: 175, width: 200, height: 50))
        txt2.text = "100 %"
        
        timer1 = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: {   timer1 in
            
            progress1.progress = progress1.progress + 0.01
            txt1.text = String(Int(progress1.progress * 100)) + " %"
            
            
            if progress1.progress >= 1.0 {
                timer1.invalidate()
            }
            }
        
                )
        
        
        
        self.view.addSubview(txt2)
        self.view.addSubview(txt1)
        self.view.addSubview(progress1)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
