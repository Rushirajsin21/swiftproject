//
//  KingFisherLibrary.swift
//  FirstProject
//
//  Created by UBS_0R on 04/07/22.
//

import UIKit
import Kingfisher

class KingFisherLibrary: UIViewController {

    @IBOutlet weak var image2: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.downloadImage(with: "https://www.google.com/logos/2013/estonia_independence_day_2013-1057005.3-hp.jpg")
    }
    func downloadImage(`with` urlString : String){
        guard let url = URL.init(string: urlString) else {
            return
        }
        let resource = ImageResource(downloadURL: url)

        KingfisherManager.shared.retrieveImage(with: resource, options: nil, progressBlock: nil) { [self] result in
            switch result {
            case .success(let value):
                print("Image: \(value). Got from: \(value)")
                image2.image = value.image
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
