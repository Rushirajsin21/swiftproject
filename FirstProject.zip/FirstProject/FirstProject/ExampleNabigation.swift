//
//  ExampleNabigation.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class ExampleNabigation: UIViewController {

    var b = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let label1 = UILabel(frame: CGRect(x: 50, y: 200, width: 100, height: 50))
        
        label1.text = "This is navigation page"
        label1.textColor = UIColor.red
        label1.backgroundColor = UIColor.green
        print(b)
        
        self.view.addSubview(label1)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
