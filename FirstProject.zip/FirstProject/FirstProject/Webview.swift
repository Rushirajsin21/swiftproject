//
//  Webview.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class Webview: UIViewController {
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let web = UIWebView(frame: CGRect(x: 10, y: 10, width: 240, height: 128))
        let url = URL(string: "https://www.example.com")
        let requestObj = URLRequest(url: url! as URL)
        web.loadRequest(requestObj)
        web.reload()
        web.goBack()
    
        
    
        
        
        self.view.addSubview(web)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
