//
//  UBlabel.swift
//  FirstProject
//
//  Created by UBS_0R on 25/06/22.
//

import Foundation
import UIKit

class UBlabel: UILabel {
    @IBInspectable
    public var cornerRadius: CGFloat = 0.0{
        didSet{
            self.layer.cornerRadius = self.cornerRadius
        }
        
    }
    
    @IBInspectable
    public var borderColor: UIColor = UIColor.clear  {
        didSet{
            self.layer.borderColor = self.borderColor.cgColor
        }
    }
    
    @IBInspectable
    public var borderWidt: CGFloat = 0.0{
        didSet{
            self.layer.borderWidth = self.borderWidt
        }
    }
}
