//
//  DynamicSegmentControl.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class DynamicSegmentControl: UIViewController {

   var item = ["1"]
    
    var a = 1
    var segment2 = UISegmentedControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    
        let btn_remove = UIButton(frame: CGRect(x: 10, y: 180, width: 100, height: 40))
        btn_remove.setTitle("Remove", for: .normal)
        btn_remove.setTitleColor(UIColor.blue, for: .normal)
        btn_remove.backgroundColor = UIColor.black
        btn_remove.layer.cornerRadius = 8
        btn_remove.addTarget(self, action: #selector(removesegment1), for: .touchUpInside)
        
        
        let btn_add = UIButton(frame: CGRect(x: 150, y: 180, width: 100, height: 40))
        btn_add.setTitle("Add", for: .normal)
        btn_add.setTitleColor(UIColor.blue, for: .normal)
        btn_add.backgroundColor = UIColor.black
        btn_add.layer.cornerRadius = 8
        btn_add.addTarget(self, action: #selector(addsegment1), for: .touchUpInside)
        segment2 = UISegmentedControl(items: item)
        segment2.frame = CGRect(x: 50, y: 100, width: 200, height: 50)
        
        self.view.addSubview(segment2)
        self.view.addSubview(btn_remove)
        self.view.addSubview(btn_add)
    }
    @objc func removesegment1(_ sender: UIButton){
       
        segment2.removeSegment(at: segment2.numberOfSegments - 1, animated: true)
    }
    @objc func addsegment1(_ sender: UIButton){
//        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
//        let viewController = storyBoard.instantiateViewController(withIdentifier: "WebviewDefintion") as! WebviewDefintion
//        //self.navigationController?.pushViewController(viewController, animated: true)
//        self.present(viewController, animated: true, completion: nil)
        
//        let storyboard1: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let viewcontroller2 = storyboard1.instantiateViewController(withIdentifier: "ExampleNabigation") as! ExampleNabigation
//        self.navigationController?.pushViewController(viewcontroller2, animated: true)
//        viewcontroller2.modalPresentationStyle = .fullScreen
//        self.present(viewcontroller2, animated: true, completion: nil)
        
        segment2.insertSegment(withTitle: "\(segment2.numberOfSegments + 1)", at: segment2.numberOfSegments, animated: true)
//
      
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
