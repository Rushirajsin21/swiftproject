//
//  SharedTextField18.swift
//  FirstProject
//
//  Created by UBS_0R on 04/07/22.
//

import UIKit

class SharedTextField18: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var btnShared: UIButton!
    @IBOutlet weak var txtshared: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtshared.textColor = UIColor.blue
        txtshared.addTarget(self, action: #selector(textvaluechange), for: .editingChanged)
        
        
            
    }
    
    
    @objc func textvaluechange(){
        
        
        let txtshare = txtshared.text!.trimmingCharacters(in: CharacterSet.whitespaces)
        
         
        if txtshare.isEmpty  {
            btnShared.isEnabled = false
        }
 
        if txtshare.isEmpty == false{
            btnShared.isEnabled = true
        }

    }

    @IBAction func btnshared_click(_ sender: Any) {
        let text = txtshared.text
        let textShare1 = [ text ]
        let activityViewController1 = UIActivityViewController(activityItems: textShare1 as [Any] , applicationActivities: nil)
         activityViewController1.popoverPresentationController?.sourceView = self.view
        activityViewController1.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ,UIActivity.ActivityType.message ,UIActivity.ActivityType.mail , UIActivity.ActivityType.markupAsPDF,UIActivity.ActivityType.addToReadingList , UIActivity.ActivityType.assignToContact , UIActivity.ActivityType.openInIBooks , UIActivity.ActivityType.postToTwitter]
         self.present(activityViewController1, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
