//
//  ActionSheetDefiniton.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class ActionSheetDefiniton: UIViewController {
    let select_gender = UIButton(frame: CGRect(x: 50, y: 100, width: 200, height: 40))
    
    let img1 = UIImageView(frame: CGRect(x: 50, y: 200, width: 100, height: 100))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        select_gender.setTitle("Select gender", for: .normal)
        select_gender.setTitleColor(UIColor.white, for: .normal)
        select_gender.backgroundColor = UIColor.black
        select_gender.clipsToBounds = true
        select_gender.layer.borderColor = UIColor.white.cgColor
        select_gender.layer.cornerRadius = 8
        select_gender.layer.borderWidth = 5
        select_gender.contentMode = .center
        select_gender.addTarget(self, action: #selector(showaction), for: .touchUpInside)
        
        img1.image = UIImage(named: "imgSelectedIcon")
        img1.layer.borderWidth = 2
        img1.layer.borderColor = UIColor.green.cgColor
        img1.layer.cornerRadius = 8
        img1.contentMode = .scaleToFill
        img1.isUserInteractionEnabled = true
        let gest = UITapGestureRecognizer(target: self, action: #selector(onappimage))
        self.img1.addGestureRecognizer(gest)
        
        
        
        
        self.view.addSubview(img1)
        self.view.addSubview(select_gender)
    }
    
    @objc func onappimage(_ sender: UITapGestureRecognizer){
        let alert2 = UIAlertController(title: "Media", message: "Select Media", preferredStyle: .actionSheet)
        
        alert2.addAction(UIAlertAction(title: "Photos", style: .default, handler: {(photoaction) in
            print(photoaction.title!)
            }))
        alert2.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(cameraaction) in
            print(cameraaction.title!)
        }))
        alert2.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {(cancelaction) in
            print(cancelaction.title!)
        }))
        self.present(alert2, animated: true, completion: nil)
                         
    }
    
    
    @objc func showaction(_ sender: UIButton){
        let alert1 = UIAlertController(title: "Select Gender", message: "What is Your Gender", preferredStyle: .actionSheet)
        alert1.addAction(UIAlertAction(title: "Male", style: .default, handler: {( maleaction) in
            self.select_gender.setTitle(maleaction.title, for: .normal)
        }))
        
        alert1.addAction(UIAlertAction(title: "Female", style: .default, handler: {(femaleactio) in
            self.select_gender.setTitle(femaleactio.title, for: .normal)
        }))
        alert1.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {(cancelaction) in
        
        }))
        self.present(alert1, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
