//
//  AlertViewController.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class AlertViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let button = UIButton(frame: CGRect(x: 100, y: 60, width: 200, height: 50))
            
        button.setTitle("Alert or warning", for: .normal)
        button.setTitleColor(.blue, for: .normal)
        button.backgroundColor = UIColor.black
        button.addTarget(self, action: #selector(onClickSingleButton), for: .touchUpInside)
        
      
        self.view.addSubview(button)
        
        
    }
    
    @objc func alertshow (_ sender: UIButton){
        let alert1 = UIAlertController(title: "Alert", message: "demo message", preferredStyle: UIAlertController.Style.alert)
        
        alert1.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        alert1.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.destructive, handler: nil))
        self.present(alert1, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onClickSingleButton(_ sender: Any)
        {
            
            let myAlert = UIAlertController(title: "Title", message: "Hello this is message Body", preferredStyle: .alert)
            
            myAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: { (alertAction) in
                print("Okay Button click\(alertAction)")
            }))
            myAlert.addAction(UIAlertAction(title: "NO", style: .destructive, handler: {(alertaction) in
                print("NO")}))
            
            self.present(myAlert, animated: true, completion: nil)
        }

}
