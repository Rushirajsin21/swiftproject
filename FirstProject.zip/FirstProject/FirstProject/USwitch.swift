//
//  USwitch.swift
//  FirstProject
//
//  Created by UBS_0R on 27/06/22.
//

import UIKit

class USwitch: UIViewController {

    @IBOutlet weak var switch2: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        let uswitch = UISwitch(frame: CGRect(x: 100, y: 100, width: 50, height: 50))
        uswitch.addTarget(self, action: #selector(self.switchChange), for: .valueChanged)
        uswitch.setOn(false, animated: false)
        uswitch.tintColor = .red
//        uswitch.onTintColor = .red
//        uswitch.backgroundColor = .yellow
        uswitch.clipsToBounds = true
         // the "off" color
       // the "on" color
        uswitch.thumbTintColor = UIColor.blue
       
        UISwitch.appearance().tintColor = .red
        uswitch.subviews[0].subviews[0].backgroundColor = UIColor.red
        switch2.subviews[0].subviews[0].backgroundColor = UIColor.red
        switch2.thumbTintColor = UIColor.red
        switch2.addTarget(self, action: #selector(switch2change), for: .valueChanged)
        self.view.addSubview(uswitch)

        // Do any additional setup after loading the view.
    }
    @objc func switchChange(_ sender:UISwitch!)
    {
        if (sender.isOn == true){
            print("UISwitch state isnow ON")
            
        }
        else{
            
            print("UISwitch state is now off")
        }
    }

    @objc func switch2change (_ sender: UISwitch!){
        if (sender.isOn == true)
        {
            switch2.thumbTintColor = UIColor.red
        }
        else{
            switch2.thumbTintColor = UIColor.blue
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
