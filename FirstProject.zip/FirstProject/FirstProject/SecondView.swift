//
//  SecondView.swift
//  FirstProject
//
//  Created by UBS_0R on 22/06/22.
//

import UIKit

class SecondView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let btn = UIButton (frame: CGRect(x: 10, y: 200, width: 200, height: 50))
        btn.setTitle("Click me", for: .normal)
        btn.isSelected = false
        
        btn.setImage(UIImage(named: "imgSelectedIcon.jpeg"), for: .normal)
        btn.setTitleColor(UIColor.blue, for: .normal)
        
        btn.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
//        btn.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        btn.attributedTitle(for: .normal)
        btn.tintColor = UIColor.red
        btn.addTarget(self, action: #selector(onClickButton),  for: .touchUpInside)
        btn.alpha = 0.5
        btn.bounds = CGRect(x: 100, y: 200, width: 50, height: 50)
        btn.backgroundColor = UIColor.green
//        btn.layer.cornerRadius = btn.frame.size.height / 2
        btn.layer.borderColor = UIColor.purple.cgColor
//        btn.layer.borderWidth = 4
        
        
        
        
        
        self.view.addSubview(btn)
        
        
//        let btn = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
//
//        btn.center = CGPoint(x: 210, y: 350)
//        btn.contentHorizontalAlignment = .center
//        btn.setTitle("Press Me", for: .normal)
//        btn.layer.borderWidth = 2.0
//        btn.layer.borderColor = UIColor.green.cgColor
//        btn.setTitleColor(.yellow, for: .normal)
//        btn.backgroundColor = UIColor.red
//        self.view.addSubview(btn)


        // Do any additional setup after loading the view.
    }
    

    @objc func onClickButton()
    {
        print("BUTTON CLICK")
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
