//
//  NSURlImage.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class NSURlImage: UIViewController {
    let img2 = UIImageView(frame: CGRect(x: 00, y: 200, width: 100, height: 100))
    let img3 = UIImageView(frame: CGRect(x: 150, y: 200, width: 100, height: 100))
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        img2.layer.borderWidth = 3
        img2.layer.borderColor = UIColor.red.cgColor
        img2.layer.cornerRadius = 10
        img2.clipsToBounds = true
        img2.contentMode = .scaleAspectFit
        img2.backgroundColor = UIColor.blue
        
        img3.layer.borderWidth = 3
        img3.layer.borderColor = UIColor.blue.cgColor
        img3.layer.cornerRadius = 10
        img3.clipsToBounds = true
        img3.contentMode = .scaleToFill
        img3.backgroundColor = UIColor.green
        
        let url1 = URL(string: "https://developerclouds.com/wp-content/uploads/2016/04/color-change-mouse.jpg")
        downloadimage(from: url1!)
        
        let url = URL(string: "https://developerclouds.com/wp-content/uploads/2016/04/color-change-mouse.jpg")
        
        img2.image = loadurl(url: url!)
        
        self.view.addSubview(img3)
        self.view.addSubview(img2)
        
        
    }
    
    func getData (from url1: URL ,completion: @escaping (Data?, URLResponse?, Error?) -> () ){
        URLSession.shared.dataTask(with: url1, completionHandler: completion).resume()
    }
    func downloadimage(from url1: URL){
        print("Download Started")
        getData(from: url1){data , response , error in
            guard let data = data , error == nil else {return}
            print(response?.suggestedFilename ?? url1.lastPathComponent)
            print("Download Finished")
            
            DispatchQueue.main.async {
                [weak self] in
                
                self?.img3.image = UIImage(data: data)
            }
 
        }
        
    }
    private func loadurl(url: URL) -> UIImage?{
        
       
       
           
            let imageData =  NSData(contentsOf: url)
            return UIImage(data: imageData! as Data)
           
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
