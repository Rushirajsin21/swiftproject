//
//  tblViewCell.swift
//  FirstProject
//
//  Created by UBS_0R on 01/07/22.
//

import UIKit

class tblViewCell: UITableViewCell {

    @IBOutlet weak var lblnumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
