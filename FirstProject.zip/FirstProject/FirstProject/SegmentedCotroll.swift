//
//  SegmentedCotroll.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class SegmentedCotroll: UIViewController {

    
    
   
    @IBOutlet weak var seg2: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       
        let item = ["red","green","blue"]
    
       let segmented = UISegmentedControl(items: item)
        
        seg2.setTitle("red", forSegmentAt: 0)
        seg2.setTitle("green", forSegmentAt: 1)
        seg2.setTitle("blue", forSegmentAt: 2)
        seg2.selectedSegmentIndex = 0
        seg2.addTarget(self, action: #selector(segmentchange2), for: .valueChanged)
        
        
        segmented.frame = CGRect(x: 10, y: 100, width: (self.view.frame.width - 20), height: 50)
        segmented.addTarget(self, action: #selector(segmentchange), for: .valueChanged)
        segmented.selectedSegmentIndex = 1
        segmented.backgroundColor = UIColor.green
        
        
        
        self.view.addSubview(segmented)
        
        
    }
    @objc func segmentchange(_ sender1:UISegmentedControl ){
        switch (sender1.selectedSegmentIndex){
        case 0:
            print("First segemnt tapped")
            sender1.backgroundColor = UIColor.red
        break
        case 1:
            print("Second segemnt tapped")
            sender1.backgroundColor = UIColor.green
        break
        case 2:
            print("Third segemnt tapped")
            sender1.backgroundColor = UIColor.blue
        break
            
        default:
            print("Segment not tapped")
            break
        }
    }
    @objc func segmentchange2(_ sender:UISegmentedControl ){
        switch (sender.selectedSegmentIndex){
        case 0:
            print("First segemnt tapped")
            sender.backgroundColor = UIColor.red
        break
        case 1:
            print("Second segemnt tapped")
            sender.backgroundColor = UIColor.green
        break
        case 2:
            print("Third segemnt tapped")
            sender.backgroundColor = UIColor.blue
        break
            
        default:
            print("Segment not tapped")
            break
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
