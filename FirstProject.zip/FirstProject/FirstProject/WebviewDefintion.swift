//
//  WebviewDefintion.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//
import WebKit
import UIKit

class WebviewDefintion: UIViewController, WKNavigationDelegate {

    let textfield1 = UITextField(frame: CGRect(x: 50, y: 50, width: 200, height: 30))
    let btn_go = UIButton(frame: CGRect(x: 240, y: 50, width: 100, height: 30))
    let web = WKWebView(frame: CGRect(x: 0, y: 100, width: 300, height: 500))
 

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        textfield1.keyboardType = .URL
        textfield1.borderStyle = .roundedRect
        textfield1.contentMode = .center
        textfield1.clipsToBounds = true
        
        btn_go.setTitle("Go", for: .normal)
        btn_go.setTitleColor(UIColor.blue, for: .normal)
        btn_go.addTarget(self, action: #selector(showview), for: .touchUpInside)
        web.navigationDelegate = self
        
                self.view.addSubview(btn_go)
        self.view.addSubview(textfield1)
        self.view.addSubview(web)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
       
       
        print("complete")
        
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if web.isLoading {
            print("loading")
        }
        print("Start")
        
    }
    
    
    @objc func showview(_ sender: UIButton){
        
        let a: String = textfield1.text ?? "https://www.google.com/"
        let url2 = URL(string: "https://developerclouds.com/wp-content/uploads/2016/04/color-change-mouse.jpg")
        let url1 = (URL(string: a) ?? url2!)
        
        let reqobj = URLRequest(url: url1 )
        web.load(reqobj)
        textfield1.resignFirstResponder()
        
        
       
    
        
        
    }
 // https://www.example.com

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
