//
//  NavigationRootcontroller.swift
//  FirstProject
//
//  Created by UBS_0R on 30/06/22.
//

import UIKit

class NavigationRootcontroller: UIViewController {
    var a = "as"
    var txtName: UITextField!
    var btnSend: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let btn_navigate = UIButton(frame: CGRect(x: 50, y: 100, width: 100, height: 50))
        btn_navigate.setTitle("Next Screen", for: .normal)
        btn_navigate.setTitleColor(UIColor.green, for: .normal)
        btn_navigate.backgroundColor = UIColor.red
        btn_navigate.addTarget(self, action: #selector(navigatescreen), for: .touchUpInside)
        
        txtName = UITextField(frame: CGRect(x: 50, y: 200, width: 200, height: 40))
        txtName.borderStyle = .roundedRect
        txtName.contentMode = .scaleToFill
        txtName.textColor = .red
        
        
        btnSend = UIButton(frame: CGRect(x: 50, y: 250, width: 200, height: 40))
        btnSend.setTitleColor(UIColor.blue, for: .normal)
        btnSend.setTitle("send", for: UIControl.State.normal)
        btnSend.addTarget(self, action: #selector(sendtonext), for: .touchUpInside)
        
        
        
        
        
        self.view.addSubview(btnSend)
        
        
        self.view.addSubview(txtName)
        self.view.addSubview(btn_navigate)
    }
    @objc func sendtonext(_ sender: UIButton){
        let storyboard2: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewcontroller2 = storyboard2.instantiateViewController(withIdentifier: "ExampleNabigation") as! ExampleNabigation
        a = txtName.text!
        viewcontroller2.b = a
        viewcontroller2.title = a
        self.navigationController?.pushViewController(viewcontroller2, animated: true)
    }
    
    @objc func navigatescreen(_ sender: UIButton){
        let storyboard1: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewcontroller1 = storyboard1.instantiateViewController(withIdentifier: "ExampleNabigation") as! ExampleNabigation
        viewcontroller1.b = a
        viewcontroller1.title = a
        self.navigationController?.pushViewController(viewcontroller1, animated: true)
        
       
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
