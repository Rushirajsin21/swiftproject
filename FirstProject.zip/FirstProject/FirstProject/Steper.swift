//
//  Steper.swift
//  FirstProject
//
//  Created by UBS_0R on 28/06/22.
//

import UIKit

class Steper: UIViewController {
    @IBOutlet weak var lb2: UILabel!
    @IBOutlet weak var step2: UIStepper!
    let lb1 = UILabel(frame: CGRect(x: 140, y: 60, width: 200, height: 50))
    override func viewDidLoad() {
        super.viewDidLoad()

        let step = UIStepper(frame: CGRect(x: 100, y: 120, width: 200, height: 50))
       
        lb1.text = "0"
        step.wraps = true
        step.autorepeat = true
        step.maximumValue = 10
        step.addTarget(self, action: #selector(steperchange), for: .valueChanged)
        // Do any additional setup after loading the view.
        
        step2.wraps = true
        step2.maximumValue = 10
        step2.addTarget(self, action: #selector(steperchange2), for: .valueChanged)
        step2.backgroundColor = UIColor.red
        step2.clipsToBounds = true
        step2.layer.cornerRadius = 8
        self.view.addSubview(lb1)
        self.view.addSubview(step)
        
    }
    
    @objc func steperchange(_ sender: UIStepper){
        lb1.text = String(Int(sender.value))
    }
    @objc func steperchange2(_ sender2: UIStepper){
        lb2.text = String(Int(sender2.value))
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
