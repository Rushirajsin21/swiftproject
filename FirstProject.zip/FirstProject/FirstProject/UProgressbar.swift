//
//  UProgressbar.swift
//  FirstProject
//
//  Created by UBS_0R on 27/06/22.
//

import UIKit

class UProgressbar: UIViewController {
    
    
    @IBOutlet weak var text2: UILabel!
    @IBOutlet weak var progressbar2: UIProgressView!
    var timer1: Timer?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let text1 = UILabel(frame: CGRect(x: 270, y: 90, width: 200, height: 50))
        let uprogress = UIProgressView(frame: CGRect(x: 100, y: 140, width: 200, height: 50))
        uprogress.progressViewStyle = .bar
        uprogress.setProgress(0.0, animated: false)
        uprogress.trackTintColor = .red
        uprogress.tintColor = .blue
        timer1 = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { [self]  timer1 in
                
            progressbar2.progress = progressbar2.progress + 0.01
            text2.text = String(Int(progressbar2.progress * 100)) + " %"
            uprogress.progress = uprogress.progress + 0.01
            text1.text = String(Int(uprogress.progress * 100)) + " %"
            if uprogress.progress >= 1.0 && progressbar2.progress >= 1.0{
                timer1.invalidate()
            }
        })
        
        
        self.view.addSubview(uprogress)
        self.view.addSubview(text1)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
