//
//  View1.swift
//  FirstProject
//
//  Created by UBS_0R on 27/06/22.
//

import UIKit

class View1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let view1 = UIView (frame: CGRect(x: 10, y: 100, width: 300, height: 200))
        view1.layer.cornerRadius = 13
        view1.backgroundColor = UIColor.red
        view1.alpha = 0.8
        view1.layer.borderWidth = 4
        view1.layer.borderColor = UIColor.green.cgColor
 
        
        
        
        self.view.addSubview(view1)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
