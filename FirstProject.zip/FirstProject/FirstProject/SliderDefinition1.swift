//
//  SliderDefinition1.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class SliderDefinition1: UIViewController {

   
    @IBOutlet weak var View1: UIView!
    let txt1 = UILabel(frame: CGRect(x: 250, y: 70, width: 100, height: 40))
    
    let txt2 = UILabel(frame: CGRect(x: 250, y: 110, width: 100, height: 40))
    let txt3 = UILabel(frame: CGRect(x: 250, y: 150, width: 100, height: 40))
    let txt4 = UILabel(frame: CGRect(x: 250, y: 190, width: 100, height: 40))
    
    var rg: CGFloat = 248
    var gg: CGFloat = 149
    var bg: CGFloat = 6
    var ag: CGFloat = 1.0
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
        let label1 = UILabel(frame: CGRect(x: 30, y: 70, width: 100, height: 40))
    
        label1.text = "Red"
        View1.backgroundColor = UIColor(red: rg/255, green: gg/255, blue: bg/255, alpha: ag)
        let label2 = UILabel(frame: CGRect(x: 30, y: 110, width: 100, height: 40))
    
        label2.text = "Green"
        
        let label3 = UILabel(frame: CGRect(x: 30, y: 150, width: 100, height: 40))
    
        label3.text = "Blue"
        
        let label4 = UILabel(frame: CGRect(x: 30, y: 190, width: 100, height: 40))
    
        label4.text = "Alpha"
        
        
        
        let slider1 = UISlider(frame: CGRect(x: 90, y: 70, width: 150, height: 40))
        slider1.maximumValue = 255
        slider1.minimumValue = 0
        slider1.setValue(50, animated: true)
        slider1.addTarget(self, action: #selector(slider1change), for: .valueChanged)
        
        
        
        let slider2 = UISlider(frame: CGRect(x: 90, y: 110, width: 150, height: 40))
        slider2.maximumValue = 255
        slider2.minimumValue = 0
        slider2.setValue(50, animated: true)
        slider2.addTarget(self, action: #selector(slider2change), for: .valueChanged)
        
        
        
        let slider3 = UISlider(frame: CGRect(x: 90, y: 150, width: 150, height: 40))
        slider3.maximumValue = 255
        slider3.minimumValue = 0
        slider3.setValue(50, animated: true)
        slider3.addTarget(self, action: #selector(slider3change), for: .valueChanged)
        
        
        let slider4 = UISlider(frame: CGRect(x: 90, y: 190, width: 150, height: 40))
        slider4.maximumValue = 1.0
        slider4.minimumValue = 0.0
        slider4.setValue(0.5, animated: true)
        slider4.addTarget(self, action: #selector(slider4change), for: .valueChanged)
        
        
        txt1.text = String(Int(slider1.value))
        txt2.text = String(Int(slider2.value))
        txt3.text = String(Int(slider3.value))
        txt4.text = String(format: "%.2f", Float(slider4.value))
        
        

        self.view.addSubview(txt4)
        self.view.addSubview(txt3)
        self.view.addSubview(txt2)
        self.view.addSubview(txt1)
        self.view.addSubview(slider4)
        self.view.addSubview(slider3)
        self.view.addSubview(slider2)
        self.view.addSubview(slider1)
        self.view.addSubview(label4)
        self.view.addSubview(label3)
        self.view.addSubview(label2)
        self.view.addSubview(label1)
    }
    
    @objc func slider1change(_ sender:UISlider){
        txt1.text = String(Int(sender.value))
        rg = CGFloat(sender.value)
        viewchangecolor()
    }
    @objc func slider2change(_ sender:UISlider){
        txt2.text = String(Int(sender.value))
        gg = CGFloat(sender.value)
        viewchangecolor()
    }
    @objc func slider3change(_ sender:UISlider){
        txt3.text = String(Int(sender.value))
        bg = CGFloat(sender.value)
        viewchangecolor()
    }
    @objc func slider4change(_ sender:UISlider){
        txt4.text = String(format: "%.2f", Float(sender.value))
        ag = CGFloat(sender.value)
        viewchangecolor()
    }
    
    func viewchangecolor(){
        View1.backgroundColor = UIColor(red: rg/255, green: gg/255, blue: bg/255, alpha: ag)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
