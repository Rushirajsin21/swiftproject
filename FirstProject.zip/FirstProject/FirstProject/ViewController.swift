//
//  ViewController.swift
//  FirstProject
//
//  Created by UBS_0R on 22/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let label = UILabel(frame: CGRect(x: 100, y: 100, width: 200, height: 45))
        label.text = "I' am a test label hello world this is demo label"
        label.textColor = UIColor.green
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 17)
        label.highlightedTextColor = UIColor.red
        label.numberOfLines = 1
        label.isUserInteractionEnabled = false
        label.alpha = 0.9
        label.backgroundColor = UIColor.lightGray
        label.clipsToBounds = true
        label.bounds = CGRect(x: 100, y: 100, width: 200, height: 50)
//        label.frame = CGRect(x: 100, y: 100, width: 200, height: 45)
        label.isHidden = false
        label.layer.cornerRadius = label.frame.size.height / 2
        label.layer.borderColor = UIColor.purple.cgColor
        label.layer.borderWidth = 1
        
        
        label.attributedText = NSAttributedString(string: "Test")
        
        label.center = CGPoint(x: 200, y: 300)
        label.textAlignment = .center

        label.layer.borderWidth = 2.0
        label.layer.borderColor = UIColor.red.cgColor

        label.backgroundColor = UIColor.black
        label.textAlignment = NSTextAlignment.center
        label.font = UIFont(name: "Times New Roman", size: 22)
        label.layer.cornerRadius = 9
        let myAttribute = [ NSAttributedString.Key.foregroundColor: UIColor.green ]
        let mutableAttrString4 = NSMutableAttributedString(string: "terms and condition", attributes: myAttribute)
        label.attributedText = mutableAttrString4

        self.view.addSubview(label)
        
        
        

     
    }

}

