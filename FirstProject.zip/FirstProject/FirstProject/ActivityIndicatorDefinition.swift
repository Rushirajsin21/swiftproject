//
//  ActivityIndicatorDefinition.swift
//  FirstProject
//
//  Created by UBS_0R on 29/06/22.
//

import UIKit

class ActivityIndicatorDefinition: UIViewController {
    let Activiy = UIActivityIndicatorView(frame: CGRect(x: 100, y: 100, width: 100, height: 70))
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let button = UIButton(frame: CGRect(x: 70, y: 150, width: 200, height: 50))
        button.setTitle("Animate Activity", for: .normal)
        button.setTitleColor(UIColor.blue, for: .normal)
        button.addTarget(self, action: #selector(showactivity), for: .touchUpInside)
        
        
        self.view.addSubview(button)
        self.view.addSubview(Activiy)
    }
    @objc func showactivity(){
        Activiy.startAnimating()
        _ = Timer
            .scheduledTimer(withTimeInterval: 5, repeats:false, block: {
            [self] timer1 in
            Activiy.stopAnimating()
            
        })
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
