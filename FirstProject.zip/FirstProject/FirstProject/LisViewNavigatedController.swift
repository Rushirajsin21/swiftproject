//
//  LisViewNavigatedController.swift
//  FirstProject
//
//  Created by UBS_0R on 01/07/22.
//

import UIKit

class LisViewNavigatedController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    

    @IBOutlet weak var tblList: UITableView!
    var list1:[String]!
    //    var list_tableview: UITableView!
    let cellReuseIdentifier = "tblViewCell"
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblList.register(UINib(nibName: "tblViewCell", bundle: nil), forCellReuseIdentifier: "tblViewCell")
        tblList.delegate = self
        tblList.dataSource = self
        self.view.addSubview(tblList)
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list1.count

    }
    
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier , for: indexPath) as! tblViewCell
//            cell.textLabel?.text = list1[indexPath.row]
         cell.lblnumber.text = list1[indexPath.row]
         return cell
    }

        
        
        
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
